prompt --application/shared_components/security/app_access_control/admin_wh
begin
--   Manifest
--     ACL ROLE: Admin_wh
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3414731422963618
,p_default_application_id=>102
,p_default_id_offset=>149401396516438020
,p_default_owner=>'KDK'
);
wwv_flow_imp_shared.create_acl_role(
 p_id=>wwv_flow_imp.id(168109210061003720)
,p_static_id=>'ADMIN_WH'
,p_name=>'Admin_wh'
,p_version_scn=>22402971
);
wwv_flow_imp.component_end;
end;
/
