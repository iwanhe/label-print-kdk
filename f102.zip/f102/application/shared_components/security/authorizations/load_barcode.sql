prompt --application/shared_components/security/authorizations/load_barcode
begin
--   Manifest
--     SECURITY SCHEME: Load_barcode
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3414731422963618
,p_default_application_id=>102
,p_default_id_offset=>149401396516438020
,p_default_owner=>'KDK'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(168110555486032113)
,p_name=>'Load_barcode'
,p_scheme_type=>'NATIVE_IS_IN_GROUP'
,p_attribute_01=>'Admin_wh,Wh'
,p_attribute_02=>'A'
,p_version_scn=>22415526
,p_caching=>'BY_USER_BY_SESSION'
);
wwv_flow_imp.component_end;
end;
/
