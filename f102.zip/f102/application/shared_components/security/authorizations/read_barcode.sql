prompt --application/shared_components/security/authorizations/read_barcode
begin
--   Manifest
--     SECURITY SCHEME: Read_barcode
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3414731422963618
,p_default_application_id=>102
,p_default_id_offset=>149401396516438020
,p_default_owner=>'KDK'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(168110936666040485)
,p_name=>'Read_barcode'
,p_scheme_type=>'NATIVE_IS_IN_GROUP'
,p_attribute_01=>'Wh,Direktur,Administrator'
,p_attribute_02=>'A'
,p_version_scn=>22757471
,p_caching=>'BY_USER_BY_SESSION'
);
wwv_flow_imp.component_end;
end;
/
