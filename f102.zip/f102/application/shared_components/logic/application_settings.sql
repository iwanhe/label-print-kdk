prompt --application/shared_components/logic/application_settings
begin
--   Manifest
--     APPLICATION SETTINGS: 102
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3414731422963618
,p_default_application_id=>102
,p_default_id_offset=>149401396516438020
,p_default_owner=>'KDK'
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(168127213444337793)
,p_name=>'APP_ENV'
,p_value=>'DEVELOPMENT'
,p_is_required=>'Y'
,p_valid_values=>'DEVELOPMENT,PRODUCTION'
,p_version_scn=>26682588
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(168169993578155626)
,p_name=>'ACCESS_CONTROL_SCOPE'
,p_value=>'ACL_ONLY'
,p_is_required=>'N'
,p_valid_values=>'ACL_ONLY, ALL_USERS'
,p_on_upgrade_keep_value=>true
,p_required_patch=>wwv_flow_imp.id(168169641119155607)
,p_comments=>'The default access level given to authenticated users who are not in the access control list'
,p_version_scn=>22611469
);
wwv_flow_imp.component_end;
end;
/
