prompt --application/shared_components/globalization/translations
begin
--   Manifest
--     TRANSLATIONS: 102
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3414731422963618
,p_default_application_id=>102
,p_default_id_offset=>149401396516438020
,p_default_owner=>'KDK'
);
null;
wwv_flow_imp.component_end;
end;
/
