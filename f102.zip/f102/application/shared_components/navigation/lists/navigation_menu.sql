prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3414731422963618
,p_default_application_id=>102
,p_default_id_offset=>149401396516438020
,p_default_owner=>'KDK'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(160826015480215216)
,p_name=>'Navigation Menu'
,p_list_status=>'PUBLIC'
,p_version_scn=>23894602
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(160837725390215301)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(167853471844535218)
,p_list_item_display_sequence=>10.1
,p_list_item_link_text=>'Barcode Info'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-header-nav-right-cards'
,p_security_scheme=>wwv_flow_imp.id(168118036619165776)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'10'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(161248329917297898)
,p_list_item_display_sequence=>11
,p_list_item_link_text=>'Barcode'
,p_list_item_icon=>'fa-barcode'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(160864581032337518)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'History Cetak Barcode Individual'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-history'
,p_parent_list_item_id=>wwv_flow_imp.id(161248329917297898)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'6'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(160852444882302374)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Load Dan Cetak Barcode Lama'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cloud-upload'
,p_parent_list_item_id=>wwv_flow_imp.id(161248329917297898)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'4'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(168014911134128584)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Read Barcode'
,p_list_item_link_target=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-barcode-read'
,p_parent_list_item_id=>wwv_flow_imp.id(161248329917297898)
,p_security_scheme=>wwv_flow_imp.id(168110936666040485)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'19'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(161249062920306143)
,p_list_item_display_sequence=>12
,p_list_item_link_text=>'Setup Dan Master Data'
,p_list_item_icon=>'fa-database-wrench'
,p_security_scheme=>wwv_flow_imp.id(168119938192204568)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(161109363517613951)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Master Serial Barcode'
,p_list_item_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-database'
,p_parent_list_item_id=>wwv_flow_imp.id(161249062920306143)
,p_security_scheme=>wwv_flow_imp.id(168112369258073741)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'12,13'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(168206385200155734)
,p_list_item_display_sequence=>10000
,p_list_item_link_text=>'Administration'
,p_list_item_link_target=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user-wrench'
,p_security_scheme=>wwv_flow_imp.id(160830748100215270)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'10000'
);
wwv_flow_imp.component_end;
end;
/
