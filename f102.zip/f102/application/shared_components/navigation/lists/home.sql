prompt --application/shared_components/navigation/lists/home
begin
--   Manifest
--     LIST: Home
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3414731422963618
,p_default_application_id=>102
,p_default_id_offset=>149401396516438020
,p_default_owner=>'KDK'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(161737961399812701)
,p_name=>'Home'
,p_list_status=>'PUBLIC'
,p_version_scn=>24034553
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(168123457874260465)
,p_list_item_display_sequence=>9.1
,p_list_item_link_text=>'Barcode Info'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layout-header-nav-right-cards'
,p_security_scheme=>wwv_flow_imp.id(168118036619165776)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(161738339403850735)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Load Dan Cetak Barcode Lama'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-barcode'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(161738605617855543)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'History Cetak Barcode Individual'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-history'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(168122922253250773)
,p_list_item_display_sequence=>20.1
,p_list_item_link_text=>'Read Barcode'
,p_list_item_link_target=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-barcode-read'
,p_security_scheme=>wwv_flow_imp.id(168110936666040485)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(161738910877860430)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Master Serial Barcode'
,p_list_item_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-database'
,p_security_scheme=>wwv_flow_imp.id(168112369258073741)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
