prompt --application/shared_components/user_interface/lovs/xtd_kdk_lp_job_run_status
begin
--   Manifest
--     XTD_KDK_LP_JOB_RUN.STATUS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3414731422963618
,p_default_application_id=>102
,p_default_id_offset=>149401396516438020
,p_default_owner=>'KDK'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(161405592495695216)
,p_lov_name=>'XTD_KDK_LP_JOB_RUN.STATUS'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'XTD_KDK_LP_JOB_RUN'
,p_return_column_name=>'ID'
,p_display_column_name=>'STATUS'
,p_default_sort_column_name=>'STATUS'
,p_default_sort_direction=>'ASC'
,p_version_scn=>11310165
);
wwv_flow_imp.component_end;
end;
/
