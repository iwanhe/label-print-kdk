prompt --application/pages/page_00019
begin
--   Manifest
--     PAGE: 00019
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3414731422963618
,p_default_application_id=>102
,p_default_id_offset=>149401396516438020
,p_default_owner=>'KDK'
);
wwv_flow_imp_page.create_page(
 p_id=>19
,p_name=>'Read Barcode'
,p_alias=>'READ-BARCODE'
,p_step_title=>'Read Barcode'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(165794608973934369)
,p_plug_name=>'Barcode Info'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>40
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(168017478535154322)
,p_name=>'Barcode Info Tabel'
,p_parent_plug_id=>wwv_flow_imp.id(165794608973934369)
,p_template=>4072358936313175081
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH bc AS (',
'    SELECT ',
'        lbi.status,',
'        lbi.avg_kk,',
'        lbi.avg_ka,',
'        lbi.avg_ab,',
'        lbi.sample_gram,',
'        v.company_code,',
'        v.specific_origin,',
'        v.net,',
'        v.gross,',
'        v.crop_year,',
'        v.quality,',
'        v.supplier',
'    FROM xtd_kdk_lp_barcode_info lbi',
'    JOIN v_kdk_lp_barcode v ',
'        ON v.barcode = lbi.barcode',
'    WHERE lbi.barcode = TRIM(:P19_BARCODE)',
'),',
'ms AS (',
'    SELECT ',
'        UPPER(content) AS content,',
'        remark,',
'        attribute1,',
'        serial',
'    FROM xtd_kdk_master_serial_barcode',
'    WHERE UPPER(content) IN (''SUPPLIER'',''OPKOPER'',''SPECIFIC ORIGIN'')',
')',
'SELECT ',
'    b.status,',
'    b.avg_kk,',
'    b.avg_ka,',
'    b.avg_ab,',
'    b.sample_gram,',
'    b.company_code AS company,',
'',
'    so.remark AS specific_origin,',
'',
'    b.net AS netto,',
'    b.gross,',
'    b.crop_year,',
'    b.quality,',
'',
'    CASE ',
'        WHEN sup.content IN (''SUPPLIER'',''OPKOPER'') ',
'        THEN sup.attribute1 || '' ('' || sup.remark || '')''',
'    END AS "SUPPLIER/OPKOPER"',
'',
'FROM bc b',
'',
'LEFT JOIN ms so',
'       ON so.serial = b.specific_origin',
'      AND so.content = ''SPECIFIC ORIGIN''',
'',
'LEFT JOIN ms sup',
'       ON sup.serial = b.supplier',
'      AND sup.content IN (''SUPPLIER'',''OPKOPER'');',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2100515439059797523
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'Tidak ada data yang ditampilkan'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(168017554691154323)
,p_query_column_id=>1
,p_column_alias=>'STATUS'
,p_column_display_sequence=>120
,p_column_heading=>'Status'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(168017632917154324)
,p_query_column_id=>2
,p_column_alias=>'AVG_KK'
,p_column_display_sequence=>80
,p_column_heading=>'Avg Kk'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(168017781138154325)
,p_query_column_id=>3
,p_column_alias=>'AVG_KA'
,p_column_display_sequence=>90
,p_column_heading=>'Avg Ka'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(168017866820154326)
,p_query_column_id=>4
,p_column_alias=>'AVG_AB'
,p_column_display_sequence=>100
,p_column_heading=>'Avg Ab'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(168017934553154327)
,p_query_column_id=>5
,p_column_alias=>'SAMPLE_GRAM'
,p_column_display_sequence=>110
,p_column_heading=>'Sample (GR)'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(168020054768154348)
,p_query_column_id=>6
,p_column_alias=>'COMPANY'
,p_column_display_sequence=>20
,p_column_heading=>'Company'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(168018110146154329)
,p_query_column_id=>7
,p_column_alias=>'SPECIFIC_ORIGIN'
,p_column_display_sequence=>30
,p_column_heading=>'Specific Origin'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(168020151385154349)
,p_query_column_id=>8
,p_column_alias=>'NETTO'
,p_column_display_sequence=>40
,p_column_heading=>'Netto'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(168018312422154331)
,p_query_column_id=>9
,p_column_alias=>'GROSS'
,p_column_display_sequence=>50
,p_column_heading=>'Gross'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(168018403179154332)
,p_query_column_id=>10
,p_column_alias=>'CROP_YEAR'
,p_column_display_sequence=>60
,p_column_heading=>'Crop Year'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(168018583151154333)
,p_query_column_id=>11
,p_column_alias=>'QUALITY'
,p_column_display_sequence=>70
,p_column_heading=>'Quality'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(168018635063154334)
,p_query_column_id=>12
,p_column_alias=>'SUPPLIER/OPKOPER'
,p_column_display_sequence=>10
,p_column_heading=>'Supplier&#x2F;opkoper'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(168015311621128620)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(160825590550215213)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(168019198994154340)
,p_plug_name=>'Scan Barcode'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>1569994581593435632
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(168019167831154339)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(168019198994154340)
,p_button_name=>'scan_barcode'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Scan Barcode'
,p_button_position=>'BUTTON_END'
,p_button_redirect_url=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-ai-sparkle-scan'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(168019017076154338)
,p_branch_action=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.::P19_BARCODE:&P19_BARCODE.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'REQUEST_IN_CONDITION'
,p_branch_condition=>'Reload'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(165794589518934368)
,p_name=>'P19_BARCODE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(168019198994154340)
,p_prompt=>'Barcode'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(168018706658154335)
,p_name=>'Barcode Changes'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P19_BARCODE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(168018818273154336)
,p_event_id=>wwv_flow_imp.id(168018706658154335)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'Reload'
,p_attribute_02=>'Y'
);
wwv_flow_imp.component_end;
end;
/
