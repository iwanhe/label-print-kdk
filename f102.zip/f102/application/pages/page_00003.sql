prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3414731422963618
,p_default_application_id=>102
,p_default_id_offset=>149401396516438020
,p_default_owner=>'KDK'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Form Add User Application'
,p_alias=>'FORM-ADD-USER-APPLICATION'
,p_page_mode=>'MODAL'
,p_step_title=>'Form Add User Application'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(168228013057203562)
,p_plug_name=>'Form Add User Application'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    A.*',
'FROM ',
'    APEX_APPL_ACL_USERS A',
'WHERE ',
'    UPPER(APPLICATION_NAME) = ''LABEL PRINT KDK'';'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(168236108459203571)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(168236509865203571)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(168236108459203571)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(168237915210203571)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(168236108459203571)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_security_scheme=>wwv_flow_imp.id(168112915159081151)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(168238355747203571)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(168236108459203571)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(168238706487203571)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(168236108459203571)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(168021409115154362)
,p_name=>'P3_PASSWORD'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(168228013057203562)
,p_prompt=>'Password'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(168228423341203563)
,p_name=>'P3_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(168228013057203562)
,p_item_source_plug_id=>wwv_flow_imp.id(168228013057203562)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(168231205267203568)
,p_name=>'P3_USER_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(168228013057203562)
,p_item_source_plug_id=>wwv_flow_imp.id(168228013057203562)
,p_prompt=>'User Name'
,p_source=>'USER_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(168232468712203568)
,p_name=>'P3_ROLE_NAMES'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(168228013057203562)
,p_item_source_plug_id=>wwv_flow_imp.id(168228013057203562)
,p_prompt=>'Role Names'
,p_source=>'ROLE_NAMES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_ONE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    UPPER(REPLACE(r.role_name, ''_'', '' '')) AS display_value,',
'    UPPER(r.role_name) AS return_value',
'FROM ',
'    apex_appl_acl_roles r',
'WHERE ',
'    r.application_id = :APP_ID',
'ORDER BY ',
'    r.role_name',
''))
,p_cSize=>60
,p_cMaxlength=>4000
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'fetch_on_search', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(168236635983203571)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(168236509865203571)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(168237483558203571)
,p_event_id=>wwv_flow_imp.id(168236635983203571)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(168021919564154367)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete user'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    -- Set the security group (workspace) ID first',
'    APEX_UTIL.SET_SECURITY_GROUP_ID(',
'        p_security_group_id => APEX_UTIL.FIND_SECURITY_GROUP_ID(''LABEL PRINT KDK'')',
'    );',
'',
'    -- Remove the user by username',
'    APEX_UTIL.REMOVE_USER(',
'        p_user_name => :P3_USER_NAME',
'    );',
'',
'    COMMIT;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'DELETE,SAVE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>18620523047716347
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(168021620911154364)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Execution Chain'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>18620224394716344
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(168239980893203573)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>18838584376765553
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(168239142861203573)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(168228013057203562)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Form Add User Application'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>18837746344765553
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(168021746424154365)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(168021620911154364)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process form Create User'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    APEX_UTIL.CREATE_USER(',
'        p_user_name                     => REPLACE(:P3_USER_NAME, '' '', ''_''),',
'        p_email_address                 => ''noreply@norep.ly'',',
'        p_web_password                  => :P3_PASSWORD,',
'        p_change_password_on_first_use  => ''N''',
'        );   ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'CREATE,SAVE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>18620349907716345
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(168021853311154366)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(168021620911154364)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Add Role'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_roles APEX_T_VARCHAR2;',
'BEGIN',
'    l_roles := APEX_STRING.SPLIT(:P3_ROLE_NAMES, '','');',
'',
'    FOR i IN 1 .. l_roles.COUNT LOOP',
'        APEX_ACL.ADD_USER_ROLE (',
'            p_application_id => :APP_ID,',
'            p_user_name      => :P3_USER_NAME,',
'            p_role_static_id => UPPER(TRIM(l_roles(i)))',
'        );',
'    END LOOP;',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        RAISE_APPLICATION_ERROR(-20001, SQLERRM);',
'END;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'CREATE,SAVE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>18620456794716346
);
wwv_flow_imp.component_end;
end;
/
