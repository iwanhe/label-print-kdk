prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3414731422963618
,p_default_application_id=>102
,p_default_id_offset=>149401396516438020
,p_default_owner=>'KDK'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Tips Penggunaan Singkat'
,p_alias=>'HELP'
,p_page_mode=>'MODAL'
,p_step_title=>'Tips Penggunaan Singkat'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(161442096594305064)
,p_plug_name=>'Help HTML'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
'    .barcode-instructions{',
'        max-width: 920px;',
'        margin: 18px auto;',
'        padding: 18px;',
'        font-family: Inter, ''Segoe UI'', Roboto, Arial, sans-serif;',
'        color: #2b2b2b;',
'    }',
'    .barcode-instructions h3{',
'        margin: 0 0 8px;',
'        color: #111827;',
'        text-decoration: underline;',
'        font-size: 1.05rem;',
'    }',
'    .section{margin-bottom: 18px}',
'    .note{font-size: 0.95rem; margin: 0}',
'    .list{padding-left: 18px; margin: 0}',
'    .chips{display:inline-flex;align-items:center;padding:2px 10px;border-radius:5px;font-weight:700;font-size:11px;color:#fff;margin-left:8px}',
'    .chips.pending{background:#F0D156;color:#3a2b00}',
'    .chips.queued{background:#D99F4E}',
'    .chips.inprogress{background:#0E05FF}',
'    .chips.finished{background:#7DDA58;color:#165a0b}',
'    .chips.failed{background:#E4080A}',
'    .chips.attempt{background:#73c1c4;color:#013737}',
'    .good-to-know li{margin-bottom:6px}',
'    .footer{font-size:13px;color:#6b7280;margin-top:6px}',
'    @media (max-width:640px){.barcode-instructions{padding:12px}}',
'</style>',
'',
'<div class="barcode-instructions">',
'    <div class="section">',
'        <h3>Instruksi Penggunaan Fitur Generate Barcode</h3>',
'        <ol class="list note">',
'            <li>Pilih baris dengan status <span class="chips pending">PENDING</span> untuk row batch yang mau di cetak.</li>',
'            <li>Klik tombol <strong><i>Generate Barcode</i></strong>.</li>',
'            <li>Row yang dipilih statusnya akan berubah menjadi <span class="chips queued">QUEUED</span> dan masuk antrian untuk pembuatan barcodenya.</li>',
'            <li>Row yang telah di proses di background status nya akan berubah menjadi <span class="chips inprogress">IN PROGRESS</span>.</li>',
'            <li>Row yang berhasil di proses akan berubah menjadi <span class="chips finished">FINISHED</span>.</li>',
'        </ol>',
'    </div>',
'',
'    <div class="section">',
'        <h3>Kasus Khusus</h3>',
'        <ol class="list note">',
'            <li>Row yang gagal status nya akan berubah menjadi <span class="chips failed">Failed</span></li>',
'            <li>Lalu setelah beberapa saat status nya akan berubah menjadi <span class="chips attempt">ATTEMPT</span></li>',
'            <li>Dan setelah itu akan berubah menjadi <span class="chips inprogress">IN PROGRESS</span> lagi.</li>',
'            <li>Jika proses nya <span class="chips failed">Failed</span> lagi. maka akan kembali ke <strong>Poin 1</strong> sampai 3 kali dan jika sudah 3 kali maka status akan tetap menjadi <span class="chips failed">Failed</span>.</li>',
'            <li>Hasil akhir jika berhasil status nya akan menjadi <span class="chips finished">FINISHED</span>.</li>',
'        </ol>',
'    </div>',
'',
'    <div class="section">',
'        <h3>Good to know :</h3>',
'        <ol class="list note good-to-know">',
'            <li>Table akan otomatis merefresh setiap <strong>5 detik</strong> untuk menampilkan status terbaru.</li>',
'            <li>Jika ada row yang dipilih maka refresh akan dipause.</li>',
'        </ol>',
'    </div>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
