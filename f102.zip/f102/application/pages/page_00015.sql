prompt --application/pages/page_00015
begin
--   Manifest
--     PAGE: 00015
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3414731422963618
,p_default_application_id=>102
,p_default_id_offset=>149401396516438020
,p_default_owner=>'KDK'
);
wwv_flow_imp_page.create_page(
 p_id=>15
,p_name=>'Form Load Barcode Info'
,p_alias=>'FORM-LOAD-BARCODE-INFO'
,p_page_mode=>'MODAL'
,p_step_title=>'Form Load Barcode Info'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(167867868983556507)
,p_plug_name=>'Button Bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P15_FILE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(167869847611556512)
,p_plug_name=>'Data Source'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(167870285543556512)
,p_plug_name=>'Upload a File'
,p_parent_plug_id=>wwv_flow_imp.id(167869847611556512)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_display_condition_type=>'ITEM_IS_NULL'
,p_plug_display_when_condition=>'P15_FILE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(167872327399556521)
,p_plug_name=>'Loaded File'
,p_parent_plug_id=>wwv_flow_imp.id(167869847611556512)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P15_FILE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(167875207490556527)
,p_name=>'Preview'
,p_template=>4501440665235496320
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH parsed AS (',
'  SELECT',
'    p.*,',
'    ROW_NUMBER() OVER (ORDER BY NULL) AS rn',
'  FROM apex_application_temp_files f',
'  CROSS JOIN TABLE(',
'    apex_data_parser.parse(',
'      p_content         => f.blob_content,',
'      p_file_name       => f.filename,',
'      p_skip_rows       => 1,',
'      p_xlsx_sheet_name => :P15_XLSX_WORKSHEET,',
'      p_file_profile    => apex_data_loading.get_file_profile(',
'                             p_static_id => ''load_barcode_info''',
'                           )',
'    )',
'  ) p',
'  WHERE f.name = :P15_FILE',
'),',
'data_rows AS (',
'  SELECT',
'    col001 AS BARCODE,',
'    col002 AS STATUS,',
'    col003 AS AVG_KK,',
'    col004 AS AVG_KA,',
'    col005 AS AVG_AB,',
'    col006 AS SAMPLE_GRAM',
'  FROM parsed',
'  WHERE rn > 1',
')',
'SELECT * FROM data_rows'))
,p_display_when_condition=>'P15_FILE'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(165793058818934353)
,p_query_column_id=>1
,p_column_alias=>'BARCODE'
,p_column_display_sequence=>10
,p_column_heading=>'Barcode'
,p_column_html_expression=>'<span style="display:inline-block;width:250px;">#BARCODE#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(165793129209934354)
,p_query_column_id=>2
,p_column_alias=>'STATUS'
,p_column_display_sequence=>20
,p_column_heading=>'Status'
,p_column_html_expression=>'<span style="display:inline-block;width:250px;">#STATUS#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(165793249555934355)
,p_query_column_id=>3
,p_column_alias=>'AVG_KK'
,p_column_display_sequence=>30
,p_column_heading=>'Avg Kk'
,p_column_html_expression=>'<span style="display:inline-block;width:250px;">#AVG_KK#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(165793300927934356)
,p_query_column_id=>4
,p_column_alias=>'AVG_KA'
,p_column_display_sequence=>40
,p_column_heading=>'Avg Ka'
,p_column_html_expression=>'<span style="display:inline-block;width:250px;">#AVG_KA#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(165793490441934357)
,p_query_column_id=>5
,p_column_alias=>'AVG_AB'
,p_column_display_sequence=>50
,p_column_heading=>'Avg Ab'
,p_column_html_expression=>'<span style="display:inline-block;width:250px;">#AVG_AB#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(165793596072934358)
,p_query_column_id=>6
,p_column_alias=>'SAMPLE_GRAM'
,p_column_display_sequence=>60
,p_column_heading=>'Sample Gram'
,p_column_html_expression=>'<span style="display:inline-block;width:400px;">#SAMPLE_GRAM#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(179377509135613272)
,p_name=>'Preview Header'
,p_template=>4501440665235496320
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ''BARCODE'' AS BARCODE,',
'    ''STATUS'' AS STATUS,',
'    ''AVG KK'' AS AVG_KK,',
'    ''AVG KA'' AS AVG_KA,',
'    ''AVG AB'' AS AVG_AB,',
'    ''SAMPLE GRAM'' AS SAMPLE_GRAM',
'FROM DUAL;'))
,p_display_when_condition=>'P15_FILE'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_header=>'<i style="color: red; font-size: 10px;">* harap cek barcode dibawah ini sebelum load</i>'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(165792433863934347)
,p_query_column_id=>1
,p_column_alias=>'BARCODE'
,p_column_display_sequence=>10
,p_column_heading=>'Barcode'
,p_column_html_expression=>'<span style="display:inline-block;width:250px;font-weight: bold;">#BARCODE#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(165792502244934348)
,p_query_column_id=>2
,p_column_alias=>'STATUS'
,p_column_display_sequence=>20
,p_column_heading=>'Status'
,p_column_html_expression=>'<span style="display:inline-block;width:250px;font-weight: bold;">#STATUS#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(165792666794934349)
,p_query_column_id=>3
,p_column_alias=>'AVG_KK'
,p_column_display_sequence=>30
,p_column_heading=>'Avg Kk'
,p_column_html_expression=>'<span style="display:inline-block;width:250px;font-weight: bold;">#AVG_KK#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(165792775739934350)
,p_query_column_id=>4
,p_column_alias=>'AVG_KA'
,p_column_display_sequence=>40
,p_column_heading=>'Avg Ka'
,p_column_html_expression=>'<span style="display:inline-block;width:250px;font-weight: bold;">#AVG_KA#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(165792807559934351)
,p_query_column_id=>5
,p_column_alias=>'AVG_AB'
,p_column_display_sequence=>50
,p_column_heading=>'Avg Ab'
,p_column_html_expression=>'<span style="display:inline-block;width:250px;font-weight: bold;">#AVG_AB#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(165792979658934352)
,p_query_column_id=>6
,p_column_alias=>'SAMPLE_GRAM'
,p_column_display_sequence=>60
,p_column_heading=>'Sample Gram'
,p_column_html_expression=>'<span style="display:inline-block;width:400px;font-weight: bold;">#SAMPLE_GRAM#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(165792356585934346)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(167869847611556512)
,p_button_name=>'download_format_load_barcode_info'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--primary:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Download Format Load Barcode Info'
,p_button_redirect_url=>'#APP_FILES#FORMAT_LOAD_BARCODE_INFO.xlsx'
,p_icon_css_classes=>'fa-download'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(167868369535556509)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(167867868983556507)
,p_button_name=>'CLEAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Clear'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(167868596844556510)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(167867868983556507)
,p_button_name=>'LOAD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Load Data'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(167870674401556513)
,p_name=>'P15_FILE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(167870285543556512)
,p_prompt=>'Upload a File'
,p_display_as=>'NATIVE_FILE'
,p_grid_label_column_span=>0
,p_field_template=>2040785906935475274
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_multiple_files', 'N',
  'content_disposition', 'attachment',
  'display_as', 'DROPZONE_BLOCK',
  'display_download_link', 'Y',
  'dropzone_description', 'Supported formats XLSX',
  'max_file_size', '5000',
  'purge_file_at', 'SESSION',
  'storage_type', 'APEX_APPLICATION_TEMP_FILES')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(167871058647556518)
,p_name=>'P15_ERROR_ROW_COUNT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(167870285543556512)
,p_display_as=>'NATIVE_HIDDEN'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(167872726021556523)
,p_name=>'P15_FILE_NAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(167872327399556521)
,p_item_default=>'Pasted Data'
,p_prompt=>'Loaded File'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(167873945818556524)
,p_name=>'P15_XLSX_WORKSHEET'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(167872327399556521)
,p_prompt=>'XLSX Worksheet'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select p.sheet_display_name,',
'       p.sheet_file_name',
'  from apex_application_temp_files f,',
'       table( apex_data_parser.get_xlsx_worksheets( p_content => f.blob_content ) ) p',
' where f.name = :P15_FILE'))
,p_cHeight=>1
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sheet_count number;',
'begin',
'    select count(*)',
'      into l_sheet_count',
'      from apex_application_temp_files f,',
'           table( apex_data_parser.get_xlsx_worksheets( p_content => f.blob_content ) ) p',
'     where f.name = :P15_FILE;',
'    ',
'     -- display if the XSLX file contains multiple worksheets',
'    return ( l_sheet_count > 1 );',
'exception',
'    when others then ',
'        return false;',
'end;'))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'execute_validations', 'N',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(167873274502556523)
,p_computation_sequence=>10
,p_computation_item=>'P15_FILE_NAME'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select filename',
'  from apex_application_temp_files ',
' where name = :P15_FILE'))
,p_compute_when=>'P15_FILE'
,p_compute_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(167873666187556524)
,p_validation_name=>'Is valid file type'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if apex_data_parser.assert_file_type(',
'       p_file_name => :P15_FILE_NAME,',
'       p_file_type => apex_data_parser.c_file_type_xlsx )',
'then',
'    return true;',
'else',
'    :P15_FILE := null;',
'    return false;',
'end if;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'Invalid file type. Supported file types XLSX.'
,p_associated_item=>wwv_flow_imp.id(167870674401556513)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(165794262889934365)
,p_validation_name=>'Barcode Is In The System'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH parsed AS (',
'  SELECT',
'    p.*,',
'    ROW_NUMBER() OVER (ORDER BY NULL) AS rn',
'  FROM apex_application_temp_files f',
'  CROSS JOIN TABLE(',
'    apex_data_parser.parse(',
'      p_content         => f.blob_content,',
'      p_file_name       => f.filename,',
'      p_skip_rows       => 1,',
'      p_xlsx_sheet_name => :P15_XLSX_WORKSHEET,',
'      p_file_profile    => apex_data_loading.get_file_profile(',
'                             p_static_id => ''load_barcode_info''',
'                           )',
'    )',
'  ) p',
'  WHERE f.name = :P15_FILE',
'),',
'data_rows AS (',
'  SELECT',
'    col001 AS BARCODE,',
'    col002 AS STATUS,',
'    col003 AS AVG_KK,',
'    col004 AS AVG_KA,',
'    col005 AS AVG_AB,',
'    col006 AS SAMPLE_GRAM',
'  FROM parsed',
'  WHERE rn > 1',
')',
'SELECT 1 ',
'FROM V_KDK_LP_BARCODE lbi',
'JOIN data_rows dr ON lbi.barcode = dr.barcode'))
,p_validation_type=>'EXISTS'
,p_error_message=>'Barcode yang diunggah tidak tercatat dalam sistem.'
,p_when_button_pressed=>wwv_flow_imp.id(167868596844556510)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(165793737683934360)
,p_validation_name=>'No Duplicate In Database'
,p_validation_sequence=>30
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH parsed AS (',
'  SELECT',
'    p.*,',
'    ROW_NUMBER() OVER (ORDER BY NULL) AS rn',
'  FROM apex_application_temp_files f',
'  CROSS JOIN TABLE(',
'    apex_data_parser.parse(',
'      p_content         => f.blob_content,',
'      p_file_name       => f.filename,',
'      p_skip_rows       => 1,',
'      p_xlsx_sheet_name => :P15_XLSX_WORKSHEET,',
'      p_file_profile    => apex_data_loading.get_file_profile(',
'                             p_static_id => ''load_barcode_info''',
'                           )',
'    )',
'  ) p',
'  WHERE f.name = :P15_FILE',
'),',
'data_rows AS (',
'  SELECT',
'    col001 AS BARCODE,',
'    col002 AS STATUS,',
'    col003 AS AVG_KK,',
'    col004 AS AVG_KA,',
'    col005 AS AVG_AB,',
'    col006 AS SAMPLE_GRAM',
'  FROM parsed',
'  WHERE rn > 1',
')',
'SELECT 1 ',
'FROM xtd_kdk_lp_barcode_info lbi',
'JOIN data_rows dr ON lbi.barcode = dr.barcode'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Data yang akan diupload ada yang sudah didatabase'
,p_when_button_pressed=>wwv_flow_imp.id(167868596844556510)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(167871492600556520)
,p_name=>'Upload a File'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P15_FILE'
,p_condition_element=>'P15_FILE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(167871900665556520)
,p_event_id=>wwv_flow_imp.id(167871492600556520)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(167874352481556526)
,p_name=>'Submit worksheet on change'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P15_XLSX_WORKSHEET'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(167874835393556527)
,p_event_id=>wwv_flow_imp.id(167874352481556526)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(165793643431934359)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'INSERT Barcode Info'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'INSERT INTO XTD_KDK_LP_BARCODE_INFO',
'(',
'    XTD_KDK_LP_BARCODE_ID,',
'    BARCODE,',
'    STATUS,',
'    AVG_KK,',
'    AVG_KA,',
'    AVG_AB,',
'    SAMPLE_GRAM',
')',
'WITH parsed AS (',
'  SELECT',
'    p.*,',
'    ROW_NUMBER() OVER (ORDER BY NULL) AS rn',
'  FROM apex_application_temp_files f',
'  CROSS JOIN TABLE(',
'    apex_data_parser.parse(',
'      p_content         => f.blob_content,',
'      p_file_name       => f.filename,',
'      p_skip_rows       => 1,',
'      p_xlsx_sheet_name => :P15_XLSX_WORKSHEET,',
'      p_file_profile    => apex_data_loading.get_file_profile(',
'                             p_static_id => ''load_barcode_info''',
'                           )',
'    )',
'  ) p',
'  WHERE f.name = :P15_FILE',
'),',
'data_rows AS (',
'  SELECT',
'    col001 AS BARCODE,',
'    col002 AS STATUS,',
'    col003 AS AVG_KK,',
'    col004 AS AVG_KA,',
'    col005 AS AVG_AB,',
'    col006 AS SAMPLE_GRAM',
'  FROM parsed',
'  WHERE rn > 1',
'),',
'barcode AS (',
'    SELECT vb.barcode_id, dr.*',
'    FROM V_KDK_LP_BARCODE vb',
'    JOIN data_rows dr ON  vb.barcode = dr.barcode',
')',
'SELECT * FROM barcode;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(167868596844556510)
,p_internal_uid=>16392246915496339
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(167869527807556512)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Clear Cache'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>':REQUEST = ''CLEAR'' or :REQUEST = ''LOAD'' or :P15_ERROR_ROW_COUNT = 0'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>18468131291118492
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(165793984474934362)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(167868596844556510)
,p_internal_uid=>16392587958496342
);
wwv_flow_imp.component_end;
end;
/
