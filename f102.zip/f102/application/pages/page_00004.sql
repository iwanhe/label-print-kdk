prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3414731422963618
,p_default_application_id=>102
,p_default_id_offset=>149401396516438020
,p_default_owner=>'KDK'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Load Dan Cetak Barcode Lama'
,p_alias=>'LOAD-DAN-CETAK-BARCODE-LAMA'
,p_step_title=>'Load Dan Cetak Barcode Lama'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(160852844159302374)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(160825590550215213)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(160853568569302377)
,p_plug_name=>'Load Dan Cetak Barcode Lama'
,p_region_name=>'staging_barcode_table'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'       SBC.ID,',
'       SBC.ID AS BUTTON,',
'       SBC.STATUS,',
'       SBC.MAT_FORM,',
'       SBC.COMPANY_CODE,',
'       SBC.BUCKET,',
'       SBC.ORIGIN,',
'       SBC.SPECIFIC_ORIGIN,',
'       SBC.QUALITY,',
'       SBC.SUPPLIER,',
'       SBC.CROP_YEAR,',
'       SBC.ADDITIONAL_INFORMATION,',
'       SBC.BATCH_NO,',
'       SBC.GROSS,',
'       SBC.TARE,',
'       SBC.NET,',
'       SBC.TOTAL_BARCODE,',
'       SBC.START_RUNNING_NUMBER,',
'       SBC.END_RUNNING_NUMBER,',
'       SBC.PREFIX_BARCODE,',
'       SBC.CREATED_DATE,',
'       SBC.CREATED_BY,',
'       CASE',
'        WHEN SBC.STATUS = ''PENDING'' THEN ''#F0D156''',
'        WHEN SBC.STATUS = ''QUEUED'' THEN ''#D99F4E''',
'        WHEN SBC.STATUS = ''IN PROGRESS'' THEN ''#0E05FF''',
'        WHEN SBC.STATUS = ''FAILED'' THEN ''#E4080A''',
'        WHEN SBC.STATUS = ''ATTEMPT'' THEN ''#98F5F9''',
'        WHEN SBC.STATUS = ''FINISHED'' THEN ''#7DDA58''',
'       END AS STATUS_COLOR',
'  from XTD_KDK_LP_STAGING_BARCODE SBC'))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160874029480355070)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160986390743843021)
,p_name=>'MAT_FORM'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MAT_FORM'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Mat Form'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160986461985843022)
,p_name=>'COMPANY_CODE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMPANY_CODE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Company Code'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160986562569843023)
,p_name=>'BUCKET'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BUCKET'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Bucket'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160986631020843024)
,p_name=>'ORIGIN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ORIGIN'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Origin'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160986789651843025)
,p_name=>'SPECIFIC_ORIGIN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SPECIFIC_ORIGIN'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Specific Origin'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160986841437843026)
,p_name=>'QUALITY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QUALITY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Quality'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160986995232843027)
,p_name=>'SUPPLIER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SUPPLIER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Supplier/Opkoper'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160987007601843028)
,p_name=>'CROP_YEAR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CROP_YEAR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Crop Year'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160987148363843029)
,p_name=>'ADDITIONAL_INFORMATION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ADDITIONAL_INFORMATION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Additional Information'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>130
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160987215142843030)
,p_name=>'BATCH_NO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BATCH_NO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Batch No'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>140
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160987318466843031)
,p_name=>'GROSS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'GROSS'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Gross'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>150
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_format_mask=>'999G999G999G999G990D0'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160987489534843032)
,p_name=>'TARE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TARE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Tare'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>160
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_format_mask=>'999G999G999G999G990D0'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160987577397843033)
,p_name=>'NET'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NET'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Net'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>170
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_format_mask=>'999G999G999G999G990D0'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160987600880843034)
,p_name=>'TOTAL_BARCODE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOTAL_BARCODE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Total Barcode'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>180
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160987744349843035)
,p_name=>'START_RUNNING_NUMBER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'START_RUNNING_NUMBER'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Start Running Number'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>190
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160987868810843036)
,p_name=>'END_RUNNING_NUMBER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'END_RUNNING_NUMBER'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'End Running Number'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>200
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160987936686843037)
,p_name=>'PREFIX_BARCODE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PREFIX_BARCODE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Prefix Barcode'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>210
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160988077243843038)
,p_name=>'CREATED_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED_DATE'
,p_data_type=>'TIMESTAMP'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Uploaded Date'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>220
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160988195939843039)
,p_name=>'CREATED_BY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED_BY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Created By'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>230
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(160991228290843070)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(161118518790621821)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'enable_multi_select', 'Y',
  'hide_control', 'N',
  'show_select_all', 'Y')).to_clob
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(161119440664621830)
,p_name=>'BUTTON'
,p_source_type=>'NONE'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_LINK'
,p_heading=>'Detail'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>40
,p_value_alignment=>'CENTER'
,p_link_target=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.::P14_XTD_KDK_LP_STAGING_BARCODE_ID:&ID.'
,p_link_text=>' <button type="button" title="Details" aria-label="Details" class="t-Button t-Button--noLabel t-Button--icon t-Button--hot"><span aria-hidden="true" class="t-Icon fa fa-file-text-o"></span></button>'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(161214178413172534)
,p_name=>'STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HTML_EXPRESSION'
,p_heading=>'Status'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>240
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'html_expression', '<div style="width: 200px;padding: 5px 10px; background-color: &STATUS_COLOR.; border-radius: 5px; color: white; text-align: center; font-weight: 900;">&STATUS.</div>')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(161214228058172535)
,p_name=>'STATUS_COLOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS_COLOR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>250
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(160873949395355069)
,p_internal_uid=>11472552878917049
,p_is_editable=>true
,p_edit_operations=>'d'
,p_delete_authorization_scheme=>wwv_flow_imp.id(168110555486032113)
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>true
,p_requires_filter=>false
,p_select_first_row=>false
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU:SAVE'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(160992570304843387)
,p_interactive_grid_id=>wwv_flow_imp.id(160873949395355069)
,p_static_id=>'115912'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(149526408496536345)
,p_report_id=>wwv_flow_imp.id(160992570304843387)
,p_view_type=>'DETAIL'
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(160992733878843388)
,p_report_id=>wwv_flow_imp.id(160992570304843387)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(149402750402470892)
,p_view_id=>wwv_flow_imp.id(160992733878843388)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(161214178413172534)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>215.979
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(149506674206217042)
,p_view_id=>wwv_flow_imp.id(160992733878843388)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(160991228290843070)
,p_is_visible=>true
,p_is_frozen=>true
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(149567164929608775)
,p_view_id=>wwv_flow_imp.id(160992733878843388)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(161119440664621830)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>96
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(160993209784843393)
,p_view_id=>wwv_flow_imp.id(160992733878843388)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(160874029480355070)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(160994116904843398)
,p_view_id=>wwv_flow_imp.id(160992733878843388)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(160986390743843021)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>86.9896
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(160995064891843399)
,p_view_id=>wwv_flow_imp.id(160992733878843388)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(160986461985843022)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>152.587
,p_sort_order=>4
,p_sort_direction=>'ASC'
,p_sort_nulls=>'LAST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(160995934832843401)
,p_view_id=>wwv_flow_imp.id(160992733878843388)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(160986562569843023)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>63.0451
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(160996854850843402)
,p_view_id=>wwv_flow_imp.id(160992733878843388)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(160986631020843024)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>64.04509999999999
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(160997764401843404)
,p_view_id=>wwv_flow_imp.id(160992733878843388)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(160986789651843025)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>134.625
,p_sort_order=>2
,p_sort_direction=>'ASC'
,p_sort_nulls=>'LAST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(160998672046843405)
,p_view_id=>wwv_flow_imp.id(160992733878843388)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(160986841437843026)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>83
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(160999501383843407)
,p_view_id=>wwv_flow_imp.id(160992733878843388)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(160986995232843027)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>123.0417
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(161000448994843409)
,p_view_id=>wwv_flow_imp.id(160992733878843388)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(160987007601843028)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>109.0278
,p_sort_order=>1
,p_sort_direction=>'ASC'
,p_sort_nulls=>'LAST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(161001370859843410)
,p_view_id=>wwv_flow_imp.id(160992733878843388)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(160987148363843029)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>151.0451
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(161002285125843412)
,p_view_id=>wwv_flow_imp.id(160992733878843388)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(160987215142843030)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>121.0312
,p_sort_order=>3
,p_sort_direction=>'ASC'
,p_sort_nulls=>'LAST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(161003143695843415)
,p_view_id=>wwv_flow_imp.id(160992733878843388)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(160987318466843031)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>77.9931
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(161004023624843416)
,p_view_id=>wwv_flow_imp.id(160992733878843388)
,p_display_seq=>17
,p_column_id=>wwv_flow_imp.id(160987489534843032)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>51
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(161004868232843418)
,p_view_id=>wwv_flow_imp.id(160992733878843388)
,p_display_seq=>18
,p_column_id=>wwv_flow_imp.id(160987577397843033)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(161005743564843420)
,p_view_id=>wwv_flow_imp.id(160992733878843388)
,p_display_seq=>19
,p_column_id=>wwv_flow_imp.id(160987600880843034)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>94.2257
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(161006605060843423)
,p_view_id=>wwv_flow_imp.id(160992733878843388)
,p_display_seq=>20
,p_column_id=>wwv_flow_imp.id(160987744349843035)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>179.247
,p_sort_order=>5
,p_sort_direction=>'ASC'
,p_sort_nulls=>'LAST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(161007498796843424)
,p_view_id=>wwv_flow_imp.id(160992733878843388)
,p_display_seq=>21
,p_column_id=>wwv_flow_imp.id(160987868810843036)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>150.615
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(161008465541843426)
,p_view_id=>wwv_flow_imp.id(160992733878843388)
,p_display_seq=>22
,p_column_id=>wwv_flow_imp.id(160987936686843037)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>134.20122137451173
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(161009322057843427)
,p_view_id=>wwv_flow_imp.id(160992733878843388)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(160988077243843038)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>181.99
,p_sort_order=>6
,p_sort_direction=>'DESC'
,p_sort_nulls=>'LAST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(161010220611843429)
,p_view_id=>wwv_flow_imp.id(160992733878843388)
,p_display_seq=>23
,p_column_id=>wwv_flow_imp.id(160988195939843039)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>94.9998298828125
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(161264894265530252)
,p_view_id=>wwv_flow_imp.id(160992733878843388)
,p_display_seq=>24
,p_column_id=>wwv_flow_imp.id(161214228058172535)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(161441899399305062)
,p_plug_name=>'Buttons Region'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(161442784648305070)
,p_plug_name=>'Warning'
,p_parent_plug_id=>wwv_flow_imp.id(161441899399305062)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>'<i style="color: red; font-weight: bold; font-size: 12px;">* harap cek data sebelum klik tombol <strong>Generate Barcode</strong></i>'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1',
'FROM xtd_kdk_lp_staging_barcode',
'WHERE STATUS = ''PENDING''',
'HAVING COUNT(*) > 0'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(161118849903621824)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(160852844159302374)
,p_button_name=>'GENERATE_BARCODE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Generate Barcode'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-ai-sparkle-generate-audio'
,p_security_scheme=>wwv_flow_imp.id(168114129625099774)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(161442018585305063)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(161441899399305062)
,p_button_name=>'Panduan'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--hoverIconPush'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Panduan'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-question-circle-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(160869284424355022)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(160852844159302374)
,p_button_name=>'UPLOAD_BARCODE_2020_2023'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--primary:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Upload Barcode'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-cloud-upload'
,p_security_scheme=>wwv_flow_imp.id(168110555486032113)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(160988552320843043)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(160852844159302374)
,p_button_name=>'UPLOAD_BARCODE_2024'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--primary:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Upload Barcode 2024'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-cloud-upload'
,p_security_scheme=>wwv_flow_imp.id(168110731128034368)
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(161215017312172543)
,p_branch_action=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::P4_SELECTED_BARCODE_IDS:&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'REQUEST_EQUALS_CONDITION'
,p_branch_condition=>'create_barcode_generator_job'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(161213916013172532)
,p_name=>'P4_SELECTED_BARCODE_IDS'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(161214765127172540)
,p_validation_name=>'No Empty IDs'
,p_validation_sequence=>10
,p_validation=>'P4_SELECTED_BARCODE_IDS'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Harus ada row dari tabel yang dipilih !!'
,p_when_button_pressed=>wwv_flow_imp.id(161118849903621824)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(161213783840172530)
,p_name=>'Get Selected Barcode'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(160853568569302377)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridselectionchange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(161824365304110332)
,p_event_id=>wwv_flow_imp.id(161213783840172530)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var copiedSelectedRows = this.data.selectedRecords;',
'var selectedItems = copiedSelectedRows',
'  .map(r => r[0]) // ID is first column',
'  .join('':'');',
'',
'apex.item("P4_SELECTED_BARCODE_IDS").setValue(selectedItems);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(161440579375305048)
,p_name=>'Refresh staging table'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(160852844159302374)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(161440679890305049)
,p_event_id=>wwv_flow_imp.id(161440579375305048)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'window.location.reload()'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(161441777481305060)
,p_name=>'Refresh IG every 5 second'
,p_event_sequence=>40
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(161441796700305061)
,p_event_id=>wwv_flow_imp.id(161441777481305060)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'setInterval(function () {',
'  var region = apex.region("staging_barcode_table");',
'  if (!region) {',
'    return;',
'  }',
'',
'  var ig$ = region.widget();',
'  var gridView = ig$.interactiveGrid("getViews", "grid");',
'  var model = gridView.model;',
'',
'  // 1. Jangan refresh kalau ada perubahan belum disimpan',
'  if (model.isChanged()) {',
'    return;',
'  }',
'',
'  // 2. Jangan refresh kalau ada row yang dipilih / dicentang',
'  var selectedRecords = gridView.getSelectedRecords();',
'  if (selectedRecords.length > 0) {',
'    return;',
'  }',
'',
'  // Refresh tabel',
'  region.refresh();',
'',
'}, 5000); // 5 detik',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(161118664877621822)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(160853568569302377)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Load Dan Cetak Barcode Lama - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>11717268361183802
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(161824429693110333)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create Job : Barcode Generator'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_job_id            XTD_KDK_LP_JOB.ID%TYPE;',
'    v_payload           CLOB;',
'',
'    v_count_forbidden   number;',
'BEGIN',
'    -- 0. Validasi untuk row dengan status yang terlarang untuk dipilih',
'    SELECT COUNT(*)',
'    INTO v_count_forbidden',
'    FROM xtd_kdk_lp_staging_barcode',
'    WHERE status IN (''QUEUED'', ''IN PROGRESS'', ''ATTEMPT'', ''FINISHED'')',
'    AND id IN (',
'        SELECT TO_NUMBER(column_value)',
'        FROM TABLE(apex_string.split(:P4_SELECTED_BARCODE_IDS, '':''))',
'    );',
'',
'    IF v_count_forbidden > 0 THEN',
'        apex_error.add_error(',
'            p_message          => ''Tidak boleh memilih baris dengan status : QUEUED, IN PROGRESS, ATTEMPT, FINISHED'',',
'            p_display_location => apex_error.c_inline_in_notification',
'        );',
'',
'        RETURN;',
'    END IF;',
'',
'    -- 1. Build payload JSON (immutable)',
'    SELECT JSON_OBJECT(',
'           ''staging_ids'' VALUE JSON_ARRAYAGG(TO_NUMBER(column_value)),',
'           ''requested_by'' VALUE :APP_USER,',
'           ''requested_at'' VALUE TO_CHAR(SYSTIMESTAMP, ''YYYY-MM-DD"T"HH24:MI:SS'')',
'           RETURNING CLOB',
'       )',
'    INTO v_payload',
'    FROM TABLE(',
'        apex_string.split(:P4_SELECTED_BARCODE_IDS, '':'')',
'    );',
'',
'    -- 2. Insert JOB',
'    INSERT INTO XTD_KDK_LP_JOB (',
'        STATUS,',
'        ATTEMPT_COUNT,',
'        CREATED_DATE,',
'        CREATED_BY',
'    ) VALUES (',
'        ''PENDING'',',
'        0,',
'        CURRENT_TIMESTAMP,',
'        :APP_USER',
'    )',
'    RETURNING ID INTO v_job_id;',
'',
'    -- simpan payload ke job',
'    UPDATE XTD_KDK_LP_JOB',
'    SET PAYLOAD = v_payload',
'    WHERE ID = v_job_id;',
'',
unistr('    -- 3. Update staging_barcode \2192 QUEUED'),
'    UPDATE XTD_KDK_LP_STAGING_BARCODE',
'    SET XTD_KDK_LP_JOB_ID = v_job_id,',
'        STATUS = ''QUEUED'',',
'        UPDATED_DATE   = CURRENT_TIMESTAMP,',
'        UPDATED_BY     = :APP_USER',
'    WHERE ID IN (',
'        SELECT TO_NUMBER(column_value)',
'        FROM TABLE(apex_string.split(:P4_SELECTED_BARCODE_IDS, '':''))',
'    );',
'',
'    COMMIT;',
'',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        ROLLBACK;',
'        RAISE;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(161118849903621824)
,p_internal_uid=>12423033176672313
);
wwv_flow_imp.component_end;
end;
/
