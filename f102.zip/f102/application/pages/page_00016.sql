prompt --application/pages/page_00016
begin
--   Manifest
--     PAGE: 00016
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3414731422963618
,p_default_application_id=>102
,p_default_id_offset=>149401396516438020
,p_default_owner=>'KDK'
);
wwv_flow_imp_page.create_page(
 p_id=>16
,p_name=>'Print Selected Barcode'
,p_alias=>'PRINT-SELECTED-BARCODE'
,p_page_mode=>'MODAL'
,p_step_title=>'Print Selected Barcode'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(161215367144172546)
,p_plug_name=>'Preview Print'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  TYPE r_bc IS RECORD (',
'    company_code           VARCHAR2(20),',
'    bucket                 VARCHAR2(20),',
'    origin                 VARCHAR2(20),',
'    mat_form               VARCHAR2(20),',
'    specific_origin        VARCHAR2(20),',
'    crop_year              VARCHAR2(20),',
'    quality                VARCHAR2(20),',
'    supplier               VARCHAR2(20),',
'    additional_information VARCHAR2(20),',
'    running_number         VARCHAR2(20),',
'    batch_no               VARCHAR2(20),',
'    gross                  VARCHAR2(20),',
'    tare                   VARCHAR2(20),',
'    net                    VARCHAR2(20),',
'    barcode                VARCHAR2(25)',
'  );',
'  ',
'  v_bc r_bc;',
'  v_barcode       VARCHAR2(20);',
'  v_serial_no     CLOB;',
'  v_created_date  varchar2(100);',
'begin',
'  -- Atur CSS untuk ukuran kertas 100 x 150 mm',
'  htp.p(''<style type="text/css" media="print">'');',
'  htp.p(''@page { margin: 0px; }'');  -- Atur ukuran kertas dan margin',
'  htp.p(''body { margin: 0; padding: 0; }'');  -- Menghilangkan margin body',
'  htp.p(''</style>'');',
'',
'  -- Sertakan library JsBarcode dari CDN',
'  htp.p(''<script src="https://cdnjs.cloudflare.com/ajax/libs/jsbarcode/3.12.1/JsBarcode.all.min.js"></script>'');',
'  ',
'  -- JavaScript untuk fungsi cetak',
'  htp.p(''<script type="text/javascript">'');',
'  htp.p(''function printdiv(divName) {'');',
'  htp.p(''  var printContents = document.getElementById(divName).innerHTML;'');',
'  htp.p(''  var originalContents = document.body.innerHTML;'');',
'  htp.p(''  document.body.innerHTML = printContents;'');',
'  htp.p(''  window.print();'');',
'  htp.p(''  document.body.innerHTML = originalContents;'');',
'  htp.p(''}'');',
'',
'    -- JavaScript untuk inisialisasi barcode setelah halaman dimuat',
'  htp.p(''document.addEventListener("DOMContentLoaded", function() {'');',
'  htp.p(''  JsBarcode(".barcode").init();'');',
'  htp.p(''});'');',
'  htp.p(''</script>'');',
'',
'  -- Tombol cetak dan konten cetak',
'  htp.p(''',
'        <div style="width: 100%; display: flex; justify-content: center;">',
'            <button style="width: 120px; height: 36px; background-color: black; border-radius: 5px; color: white; font-weight: 900;margin-bottom: 10px; text-align: center; cursor: pointer" id="print" onclick="printdiv(''''div_print1'''');">Print</button>'
||'<br/>',
'        </div>',
'   '');',
'  htp.p(''<div id="div_print1" class="container" style="margin: 0px 0px 0px 0px;">'');',
'',
'  -- Format tanggal dan waktu saat ini',
'  select to_char(CURRENT_DATE, ''DD-MON-YYYY, HH24:MI:SS'') into v_created_date from dual;',
'',
' -- Loop ambil dari data barcode yang sudah ada',
'  for rec in (',
'    SELECT TO_NUMBER(column_value) as id',
'    FROM TABLE(apex_string.split(:P16_SELECTED_BARCODE_IDS, ''-''))',
'  )',
'  loop  ',
'    SELECT',
'        sbc.company_code,',
'        sbc.bucket,',
'        sbc.origin,',
'        sbc.mat_form,',
'        sbc.specific_origin,',
'        sbc.crop_year,',
'        sbc.quality,',
'        sbc.supplier,',
'        sbc.additional_information,',
'        TO_CHAR(bc.running_number),',
'        TO_CHAR(sbc.batch_no),',
'        TO_CHAR(bc.gross),',
'        TO_CHAR(bc.tare),',
'        TO_CHAR(bc.net),',
'        bc.barcode',
'    INTO v_bc',
'    FROM xtd_kdk_lp_staging_barcode sbc',
'    JOIN xtd_kdk_lp_barcode bc',
'        ON bc.xtd_kdk_lp_staging_barcode_id = sbc.id',
'    WHERE bc.id = rec.id;',
'',
'    v_serial_no := UPPER(v_bc.mat_form || v_bc.company_code || v_bc.bucket || v_bc.origin || ''/'' || v_bc.specific_origin || v_bc.quality || v_bc.supplier || ''/'' || v_bc.crop_year || ''/'' || v_bc.additional_information);',
'    ',
'    IF :P16_IS_2024 = ''YES'' THEN',
'        v_barcode := ARRANGE_BARCODE(rec.id, TRUE);',
'    ELSE',
'        v_barcode := v_bc.barcode;',
'    END IF;',
'',
'    -- Versi rotate 180 derajat',
'    htp.p(''<div style="margin-top: 0px;"></div>'');',
'    htp.p(''<div style="transform: rotate(180deg)">'');',
'',
'    -- Nama barang dan barcode, gunakan padding langsung di table',
'    htp.p(''<table border="1" style="width:100%; border-collapse:collapse; text-align:center;">'');',
'',
'    -- Case No, Serial No, Printed',
'    htp.p(''  <tr>'');',
'    htp.p(''    <th style="font-size:10px;">Case No.</th>'');',
'    htp.p(''    <th style="font-size:10px;">Serial No.</th>'');',
'    htp.p(''    <th style="font-size:10px;">Printed</th>'');',
'    htp.p(''  </tr>'');',
'    htp.p(''  <tr>'');',
'    htp.p(''    <td style="width:33.33%; text-align:center; font-size:10px;"><b>'' || LPAD(TO_CHAR(v_bc.running_number), 5, ''0'') || ''</b></td>'');',
'    htp.p(''    <td style="width:33.33%; text-align:center; font-size:10px;"><b>'' || v_bc.batch_no || ''</b></td>'');',
'    htp.p(''    <td style="width:33.33%; text-align:center; font-size:10px;"><b>'' || v_created_date || ''</b></td>'');',
'    htp.p(''  </tr>'');',
'',
'    -- Gross, Tare, Net',
'    htp.p(''  <tr>'');',
'    htp.p(''    <th style="font-size:10px;">GROSS</th>'');',
'    htp.p(''    <th style="font-size:10px;">TARE</th>'');',
'    htp.p(''    <th style="font-size:10px;">NET</th>'');',
'    htp.p(''  </tr>'');',
'    htp.p(''  <tr>'');',
'    htp.p(''    <td style="width:33.33%; text-align:center; font-size:10px;"><b>'' || TO_CHAR(v_bc.GROSS, ''999G999G999G999G990D0'') || ''</b></td>'');',
'    htp.p(''    <td style="width:33.33%; text-align:center; font-size:10px;"><b>'' || TO_CHAR(v_bc.TARE, ''999G999G999G999G990D0'') || ''</b></td>'');',
'    htp.p(''    <td style="width:33.33%; text-align:center; font-size:10px;"><b>'' || TO_CHAR(v_bc.NET, ''999G999G999G999G990D0'') || ''</b></td>'');',
'    htp.p(''  </tr>'');',
'',
'     -- Serial number rata tengah',
'    htp.p(''  <tr>'');',
'    htp.p(''    <th colspan="3" style="font-size: 32px; font-weight: bold; text-align: center; letter-spacing: 1px;">'' || v_serial_no || ''</th>'');',
'    htp.p(''  </tr>'');',
'',
'     -- Barcode',
'    htp.p(''  <tr>'');',
'    htp.p(''    <th colspan="3" style="text-align:center;">'');',
'    htp.p(''      <div style="margin-top: 5px; margin-bottom: 5px;">''); ',
'    htp.p(''        <svg class="barcode" jsbarcode-format="CODE128" jsbarcode-value="'' || htf.escape_sc(v_barcode) || ''" jsbarcode-textmargin="0" jsbarcode-fontoptions="bold" jsbarcode-width="2" jsbarcode-height="55"></svg>'');',
'    htp.p(''      </div>'');',
'    htp.p(''    </th>'');',
'    htp.p(''  </tr>'');',
'',
'    htp.p(''</table>'');',
'',
'    -- Spasi bawah',
'    htp.p(''<div style="margin-top: 112px; margin-bottom: 112px;"></div>'');',
'    htp.p(''</div>'');',
'',
'    --=============================== Versi normal  ==================================',
' ',
'',
'  -- Nama barang dan barcode, gunakan padding langsung di table',
'    htp.p(''<table border="1" style="width:100%; border-collapse:collapse; text-align:center;">'');',
'',
'    -- Case No, Serial No, Printed',
'    htp.p(''  <tr>'');',
'    htp.p(''    <th style="font-size:10px;">Case No.</th>'');',
'    htp.p(''    <th style="font-size:10px;">Serial No.</th>'');',
'    htp.p(''    <th style="font-size:10px;">Printed</th>'');',
'    htp.p(''  </tr>'');',
'    htp.p(''  <tr>'');',
'    htp.p(''    <td style="width:33.33%; text-align:center; font-size:10px;"><b>'' || LPAD(TO_CHAR(v_bc.RUNNING_NUMBER), 5, ''0'') || ''</b></td>'');',
'    htp.p(''    <td style="width:33.33%; text-align:center; font-size:10px;"><b>'' || v_bc.batch_no || ''</b></td>'');',
'    htp.p(''    <td style="width:33.33%; text-align:center; font-size:10px;"><b>'' || v_created_date || ''</b></td>'');',
'    htp.p(''  </tr>'');',
'',
'    -- Gross, Tare, Net',
'    htp.p(''  <tr>'');',
'    htp.p(''    <th style="font-size:10px;">GROSS</th>'');',
'    htp.p(''    <th style="font-size:10px;">TARE</th>'');',
'    htp.p(''    <th style="font-size:10px;">NET</th>'');',
'    htp.p(''  </tr>'');',
'    htp.p(''  <tr>'');',
'    htp.p(''    <td style="width:33.33%; text-align:center; font-size:10px;"><b>'' || TO_CHAR(v_bc.GROSS, ''999G999G999G999G990D0'') || ''</b></td>'');',
'    htp.p(''    <td style="width:33.33%; text-align:center; font-size:10px;"><b>'' || TO_CHAR(v_bc.TARE, ''999G999G999G999G990D0'') || ''</b></td>'');',
'    htp.p(''    <td style="width:33.33%; text-align:center; font-size:10px;"><b>'' || TO_CHAR(v_bc.NET, ''999G999G999G999G990D0'') || ''</b></td>'');',
'    htp.p(''  </tr>'');',
'',
'    -- Serial number rata tengah',
'    htp.p(''  <tr>'');',
'    htp.p(''    <th colspan="3" style="font-size: 32px; font-weight: bold; text-align: center; letter-spacing: 1px;">'' || v_serial_no || ''</th>'');',
'    htp.p(''  </tr>'');',
'    ',
'    -- Barcode',
'    htp.p(''  <tr>'');',
'    htp.p(''    <th colspan="3" style="text-align:center;">'');',
'    htp.p(''      <div style="margin-top: 5px; margin-bottom: 5px;">''); ',
'    htp.p(''        <svg class="barcode" jsbarcode-format="CODE128" jsbarcode-value="'' || htf.escape_sc(v_barcode) || ''" jsbarcode-textmargin="0" jsbarcode-fontoptions="bold" jsbarcode-width="2" jsbarcode-height="55"></svg>'');',
'    htp.p(''      </div>'');',
'    htp.p(''    </th>'');',
'    htp.p(''  </tr>'');',
'',
'    htp.p(''</table>'');',
'    htp.p(''<div style="page-break-after: always;"></div>'');',
'    ',
'  end loop;',
'',
'  htp.p(''</div>'');',
'end;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(161215247659172545)
,p_name=>'P16_SELECTED_BARCODE_IDS'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(161823618294110325)
,p_name=>'P16_IS_2024'
,p_item_sequence=>20
,p_use_cache_before_default=>'NO'
,p_item_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp.component_end;
end;
/
