prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3414731422963618
,p_default_application_id=>102
,p_default_id_offset=>149401396516438020
,p_default_owner=>'KDK'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'History Cetak Barcode Individual'
,p_alias=>'HISTORY-CETAK-BARCODE-INDIVIDUAL'
,p_step_title=>'History Cetak Barcode Individual'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(160864981289337518)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(160825590550215213)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(160865663462337520)
,p_plug_name=>'History Cetak Barcode Individual'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    BC.ID AS Print,',
'    SBC.MAT_FORM,',
'    SBC.COMPANY_CODE,',
'    SBC.BUCKET,',
'    SBC.ORIGIN,',
'    SBC.SPECIFIC_ORIGIN,',
'    SBC.QUALITY,',
'    SBC.SUPPLIER,',
'    SBC.CROP_YEAR,',
'    SBC.ADDITIONAL_INFORMATION,',
'    SBC.BATCH_NO,',
'    SBC.GROSS,',
'    SBC.TARE,',
'    SBC.NET,',
'    bc.RUNNING_NUMBER,',
'    ARRANGE_BARCODE(bc.id) as barcode',
'FROM xtd_kdk_lp_barcode bc',
'JOIN xtd_kdk_lp_staging_barcode sbc ON bc.xtd_kdk_lp_staging_barcode_id = sbc.id',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'History Cetak Barcode Individual'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(160865786674337520)
,p_name=>'History Cetak Barcode Individual'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'ADMIN'
,p_internal_uid=>11464390157899500
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161216657723172559)
,p_db_column_name=>'PRINT'
,p_display_order=>10
,p_column_identifier=>'U'
,p_column_label=>'Print'
,p_column_link=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.::P16_SELECTED_BARCODE_IDS:#PRINT#'
,p_column_linktext=>' <button type="button" title="Details" aria-label="Details" class="t-Button t-Button--noLabel t-Button--icon t-Button--hot"><span aria-hidden="true" class="t-Icon fa fa-print"></span></button>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_security_scheme=>wwv_flow_imp.id(168116438359132232)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(158650731975116959)
,p_db_column_name=>'MAT_FORM'
,p_display_order=>20
,p_column_identifier=>'H'
,p_column_label=>'Mat Form'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(158650809779116960)
,p_db_column_name=>'COMPANY_CODE'
,p_display_order=>30
,p_column_identifier=>'I'
,p_column_label=>'Company Code'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(158650927821116961)
,p_db_column_name=>'BUCKET'
,p_display_order=>40
,p_column_identifier=>'J'
,p_column_label=>'Bucket'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(158651002176116962)
,p_db_column_name=>'ORIGIN'
,p_display_order=>50
,p_column_identifier=>'K'
,p_column_label=>'Origin'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(158651163332116963)
,p_db_column_name=>'SPECIFIC_ORIGIN'
,p_display_order=>60
,p_column_identifier=>'L'
,p_column_label=>'Specific Origin'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(158651210595116964)
,p_db_column_name=>'QUALITY'
,p_display_order=>70
,p_column_identifier=>'M'
,p_column_label=>'Quality'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(158651336032116965)
,p_db_column_name=>'SUPPLIER'
,p_display_order=>80
,p_column_identifier=>'N'
,p_column_label=>'Supplier'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(158651438176116966)
,p_db_column_name=>'CROP_YEAR'
,p_display_order=>90
,p_column_identifier=>'O'
,p_column_label=>'Crop Year'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(158651500398116967)
,p_db_column_name=>'ADDITIONAL_INFORMATION'
,p_display_order=>100
,p_column_identifier=>'P'
,p_column_label=>'Additional Information'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(158651609811116968)
,p_db_column_name=>'BATCH_NO'
,p_display_order=>110
,p_column_identifier=>'Q'
,p_column_label=>'Batch No'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(158651760417116969)
,p_db_column_name=>'GROSS'
,p_display_order=>120
,p_column_identifier=>'R'
,p_column_label=>'Gross'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(158651848030116970)
,p_db_column_name=>'TARE'
,p_display_order=>130
,p_column_identifier=>'S'
,p_column_label=>'Tare'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(160869157713355021)
,p_db_column_name=>'NET'
,p_display_order=>140
,p_column_identifier=>'T'
,p_column_label=>'Net'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(160867174494337523)
,p_db_column_name=>'RUNNING_NUMBER'
,p_display_order=>150
,p_column_identifier=>'C'
,p_column_label=>'Running Number'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(161216795993172560)
,p_db_column_name=>'BARCODE'
,p_display_order=>170
,p_column_identifier=>'V'
,p_column_label=>'Barcode'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(160902131833396727)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'115008'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PRINT:BARCODE:MAT_FORM:COMPANY_CODE:BUCKET:ORIGIN:SPECIFIC_ORIGIN:QUALITY:SUPPLIER:CROP_YEAR:ADDITIONAL_INFORMATION:BATCH_NO:GROSS:TARE:NET:RUNNING_NUMBER:'
);
wwv_flow_imp.component_end;
end;
/
