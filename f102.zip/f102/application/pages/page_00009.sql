prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3414731422963618
,p_default_application_id=>102
,p_default_id_offset=>149401396516438020
,p_default_owner=>'KDK'
);
wwv_flow_imp_page.create_page(
 p_id=>9
,p_name=>'Form Load Barcode 2024'
,p_alias=>'FORM-LOAD-BARCODE-2024'
,p_page_mode=>'MODAL'
,p_step_title=>'Form Load Barcode 2024'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(161029568324418616)
,p_plug_name=>'Button Bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P9_FILE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(161031539833418626)
,p_plug_name=>'Data Source'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(161031991205418629)
,p_plug_name=>'Upload a File'
,p_parent_plug_id=>wwv_flow_imp.id(161031539833418626)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>30
,p_plug_display_condition_type=>'ITEM_IS_NULL'
,p_plug_display_when_condition=>'P9_FILE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(161034039690418645)
,p_plug_name=>'Loaded File'
,p_parent_plug_id=>wwv_flow_imp.id(161031539833418626)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>40
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P9_FILE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(161036980478418654)
,p_name=>'Preview'
,p_template=>4501440665235496320
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH parsed AS (',
'  SELECT',
'    p.*,',
'    ROW_NUMBER() OVER (ORDER BY NULL) AS rn',
'  FROM apex_application_temp_files f',
'  CROSS JOIN TABLE(',
'    apex_data_parser.parse(',
'      p_content         => f.blob_content,',
'      p_file_name       => f.filename,',
'      p_skip_rows       => 1,',
'      p_xlsx_sheet_name => :P9_XLSX_WORKSHEET,',
'      p_file_profile    => apex_data_loading.get_file_profile(',
'                             p_static_id => ''load_staging_barcode_2024''',
'                           )',
'    )',
'  ) p',
'  WHERE f.name = :P9_FILE',
'),',
'',
'data_rows AS (',
'  SELECT',
'    UPPER(col001) AS mat_form,',
'    UPPER(col002) AS company_code,',
'    UPPER(col003) AS bucket,',
'    UPPER(col004) AS origin,',
'    UPPER(col005) AS specific_origin,',
'    UPPER(col006) AS quality,',
'    UPPER(col007) AS supplier,',
'',
'    CASE',
'      WHEN REGEXP_LIKE(col008, ''^\d+$'')',
'      THEN TO_NUMBER(col008)',
'      ELSE NULL',
'    END AS crop_year,',
'',
'    UPPER(col009) AS additional_information,',
'',
'    CASE',
'      WHEN REGEXP_LIKE(col010, ''^\d+$'')',
'      THEN TO_NUMBER(col010)',
'      ELSE NULL',
'    END AS batch_no,',
'',
'    CASE',
'      WHEN REGEXP_LIKE(col011, ''^\d+(\.\d+)?$'')',
'      THEN TO_NUMBER(col011)',
'      ELSE NULL',
'    END AS gross,',
'',
'    CASE',
'      WHEN REGEXP_LIKE(col012, ''^\d+(\.\d+)?$'')',
'      THEN TO_NUMBER(col012)',
'      ELSE NULL',
'    END AS tare,',
'',
'    CASE',
'      WHEN REGEXP_LIKE(col013, ''^\d+(\.\d+)?$'')',
'      THEN TO_NUMBER(col013)',
'      ELSE NULL',
'    END AS net,',
'',
'    CASE',
'      WHEN REGEXP_LIKE(col014, ''^\d+$'')',
'      THEN TO_NUMBER(col014)',
'      ELSE NULL',
'    END AS total_barcode,',
'',
'    UPPER(col015) AS PREFIX_BARCODE',
'',
'  FROM parsed',
'  WHERE rn > 1',
'),',
'existing_totals AS (',
'  SELECT',
'    company_code,',
'    crop_year,',
'    supplier,',
'    specific_origin,',
'    prefix_barcode,',
'    SUM(TOTAL_BARCODE) AS TOTAL_EXISTING',
'  FROM xtd_kdk_lp_staging_barcode',
'  GROUP BY',
'    company_code,',
'    crop_year,',
'    supplier,',
'    specific_origin,',
'    prefix_barcode',
'),',
'numbered AS (',
'  SELECT',
'    d.*,',
'    NVL(e.total_existing, 0)',
'    +',
'    NVL(',
'      SUM(d.total_barcode) OVER (',
'        PARTITION BY',
'          d.company_code,',
'          d.crop_year,',
'          d.supplier,',
'          d.specific_origin',
'        ORDER BY d.batch_no',
'        ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING',
'      ),',
'      0',
'    )',
'    + 1 AS start_running_number',
'  FROM data_rows d',
'  LEFT JOIN existing_totals e',
'    ON e.company_code    = d.company_code',
'   AND e.crop_year       = d.crop_year',
'   AND e.supplier        = d.supplier',
'   AND e.specific_origin = d.specific_origin',
'   AND e.prefix_barcode  = d.prefix_barcode',
')',
'',
'SELECT',
'  mat_form,',
'  company_code,',
'  bucket,',
'  origin,',
'  specific_origin,',
'  quality,',
'  supplier,',
'  crop_year,',
'  additional_information,',
'  batch_no,',
'  TO_CHAR(gross, ''999G999G999G999G990D0'') as gross,',
'  TO_CHAR(tare, ''999G999G999G999G990D0'') as tare,',
'  TO_CHAR(net, ''999G999G999G999G990D0'') as net,',
'  total_barcode,',
'  start_running_number,',
'  start_running_number + total_barcode - 1 AS end_running_number,',
'  prefix_barcode',
'FROM numbered',
'ORDER BY',
'  company_code,',
'  crop_year,',
'  supplier,',
'  specific_origin,',
'  batch_no;',
''))
,p_display_when_condition=>'P9_FILE'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(160989170478843049)
,p_query_column_id=>1
,p_column_alias=>'MAT_FORM'
,p_column_display_sequence=>10
,p_column_heading=>'Mat Form'
,p_column_html_expression=>'<span style="display:inline-block;width:86px;">#MAT_FORM#</span>'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(160989261757843050)
,p_query_column_id=>2
,p_column_alias=>'COMPANY_CODE'
,p_column_display_sequence=>20
,p_column_heading=>'Company Code'
,p_column_html_expression=>'<span style="display:inline-block;width:120px;">#COMPANY_CODE#</span>'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(160989298682843051)
,p_query_column_id=>3
,p_column_alias=>'BUCKET'
,p_column_display_sequence=>30
,p_column_heading=>'Bucket'
,p_column_html_expression=>'<span style="display:inline-block;width:86px;">#BUCKET#</span>'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(160989471181843052)
,p_query_column_id=>4
,p_column_alias=>'ORIGIN'
,p_column_display_sequence=>40
,p_column_heading=>'Origin'
,p_column_html_expression=>'<span style="display:inline-block;width:86px;">#ORIGIN#</span>'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(160989558363843053)
,p_query_column_id=>5
,p_column_alias=>'SPECIFIC_ORIGIN'
,p_column_display_sequence=>50
,p_column_heading=>'Specific Origin'
,p_column_html_expression=>'<span style="display:inline-block;width:120px;">#SPECIFIC_ORIGIN#</span>'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(160989616438843054)
,p_query_column_id=>6
,p_column_alias=>'QUALITY'
,p_column_display_sequence=>60
,p_column_heading=>'Quality'
,p_column_html_expression=>'<span style="display:inline-block;width:86px;">#QUALITY#</span>'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(160989778393843055)
,p_query_column_id=>7
,p_column_alias=>'SUPPLIER'
,p_column_display_sequence=>70
,p_column_heading=>'Supplier'
,p_column_html_expression=>'<span style="display:inline-block;width:86px;">#SUPPLIER#</span>'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(160989862396843056)
,p_query_column_id=>8
,p_column_alias=>'CROP_YEAR'
,p_column_display_sequence=>80
,p_column_heading=>'Crop Year'
,p_column_html_expression=>'<span style="display:inline-block;width:86px;">#CROP_YEAR#</span>'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(160989966112843057)
,p_query_column_id=>9
,p_column_alias=>'ADDITIONAL_INFORMATION'
,p_column_display_sequence=>90
,p_column_heading=>'Additional Information'
,p_column_html_expression=>'<span style="display:inline-block;width:180px;font-size: 12px;">#ADDITIONAL_INFORMATION#</span>'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(160990054965843058)
,p_query_column_id=>10
,p_column_alias=>'BATCH_NO'
,p_column_display_sequence=>100
,p_column_heading=>'Batch No'
,p_column_html_expression=>'<span style="display:inline-block;width:86px;">#BATCH_NO#</span>'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(160990160057843059)
,p_query_column_id=>11
,p_column_alias=>'GROSS'
,p_column_display_sequence=>110
,p_column_heading=>'Gross'
,p_column_html_expression=>'<span style="display:inline-block;width:86px;">#GROSS#</span>'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(160990273109843060)
,p_query_column_id=>12
,p_column_alias=>'TARE'
,p_column_display_sequence=>120
,p_column_heading=>'Tare'
,p_column_html_expression=>'<span style="display:inline-block;width:86px;">#TARE#</span>'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(160990358496843061)
,p_query_column_id=>13
,p_column_alias=>'NET'
,p_column_display_sequence=>130
,p_column_heading=>'Net'
,p_column_html_expression=>'<span style="display:inline-block;width:86px;">#NET#</span>'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(160990427029843062)
,p_query_column_id=>14
,p_column_alias=>'TOTAL_BARCODE'
,p_column_display_sequence=>140
,p_column_heading=>'Total Barcode'
,p_column_html_expression=>'<span style="display:inline-block;width:100px;font-size: 12px;">#TOTAL_BARCODE#</span>'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(160990532292843063)
,p_query_column_id=>15
,p_column_alias=>'START_RUNNING_NUMBER'
,p_column_display_sequence=>150
,p_column_heading=>'Start Running Number'
,p_column_html_expression=>'<span style="display:inline-block;width:80px;font-size: 12px;">#START_RUNNING_NUMBER#</span>'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(160990645603843064)
,p_query_column_id=>16
,p_column_alias=>'END_RUNNING_NUMBER'
,p_column_display_sequence=>160
,p_column_heading=>'End Running Number'
,p_column_html_expression=>'<span style="display:inline-block;width:80px;font-size: 12px;">#END_RUNNING_NUMBER#</span>'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(160990701054843065)
,p_query_column_id=>17
,p_column_alias=>'PREFIX_BARCODE'
,p_column_display_sequence=>170
,p_column_heading=>'Prefix Barcode'
,p_column_html_expression=>'<span style="display:inline-block;width: 130px;font-size: 12px;">#PREFIX_BARCODE#</span>'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(173186705905343991)
,p_name=>'Preview'
,p_template=>4501440665235496320
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ''MAT FORM'' AS MF,',
'    ''COMPANY CODE'' AS CC,',
'    ''BUCKET'' AS BU,',
'    ''ORIGIN'' AS "OR",',
'    ''SPECIFIC ORIGIN'' AS SO,',
'    ''QUALITY'' AS QU,',
'    ''OPKOPER'' AS SU,',
'    ''CROP YEAR'' AS CY,',
'    ''ADDITIONAL INFORMATION'' AS AI,',
'    ''BATCH NO'' AS BN,',
'    ''GROSS'' AS GR,',
'    ''TARE'' AS TA,',
'    ''NET'' AS NE,',
'    ''TOTAL BARCODE'' AS TB,',
'    ''START RUNNING NUMBER'' AS SR,',
'    ''END RUNNING NUMBER'' AS ER,',
'    ''PREFIX BARCODE'' AS PB',
'FROM DUAL;'))
,p_display_when_condition=>'P9_FILE'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_header=>'<i style="color: red; font-size: 10px;">* harap cek barcode dibawah ini sebelum load</i>'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(161695306887391124)
,p_query_column_id=>1
,p_column_alias=>'MF'
,p_column_display_sequence=>10
,p_column_heading=>'Mf'
,p_column_html_expression=>'<span style="display:inline-block;width:86px;font-weight: bold">#MF#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(161695764886391127)
,p_query_column_id=>2
,p_column_alias=>'CC'
,p_column_display_sequence=>20
,p_column_heading=>'Cc'
,p_column_html_expression=>'<span style="display:inline-block;width:120px;font-weight: bold">#CC#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(161696195327391127)
,p_query_column_id=>3
,p_column_alias=>'BU'
,p_column_display_sequence=>30
,p_column_heading=>'Bu'
,p_column_html_expression=>'<span style="display:inline-block;width:86px;font-weight: bold">#BU#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(161696553186391127)
,p_query_column_id=>4
,p_column_alias=>'OR'
,p_column_display_sequence=>40
,p_column_heading=>'Or'
,p_column_html_expression=>'<span style="display:inline-block;width:86px;font-weight: bold">#OR#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(161696974558391129)
,p_query_column_id=>5
,p_column_alias=>'SO'
,p_column_display_sequence=>50
,p_column_heading=>'So'
,p_column_html_expression=>'<span style="display:inline-block;width:120px;font-weight: bold">#SO#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(161697310512391129)
,p_query_column_id=>6
,p_column_alias=>'QU'
,p_column_display_sequence=>60
,p_column_heading=>'Qu'
,p_column_html_expression=>'<span style="display:inline-block;width:86px;font-weight: bold">#QU#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(161697783678391129)
,p_query_column_id=>7
,p_column_alias=>'SU'
,p_column_display_sequence=>70
,p_column_heading=>'Su'
,p_column_html_expression=>'<span style="display:inline-block;width:86px;font-weight: bold">#SU#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(161698154080391129)
,p_query_column_id=>8
,p_column_alias=>'CY'
,p_column_display_sequence=>80
,p_column_heading=>'Cy'
,p_column_html_expression=>'<span style="display:inline-block;width:86px;font-weight: bold">#CY#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(161698589057391130)
,p_query_column_id=>9
,p_column_alias=>'AI'
,p_column_display_sequence=>90
,p_column_heading=>'Ai'
,p_column_html_expression=>'<span style="display:inline-block;width:180px;font-size: 12px;font-weight: bold">#AI#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(161698949386391130)
,p_query_column_id=>10
,p_column_alias=>'BN'
,p_column_display_sequence=>100
,p_column_heading=>'Bn'
,p_column_html_expression=>'<span style="display:inline-block;width:86px;font-weight: bold;">#BN#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(161699321064391130)
,p_query_column_id=>11
,p_column_alias=>'GR'
,p_column_display_sequence=>110
,p_column_heading=>'Gr'
,p_column_html_expression=>'<span style="display:inline-block;width:86px;font-weight: bold;">#GR#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(161699776539391130)
,p_query_column_id=>12
,p_column_alias=>'TA'
,p_column_display_sequence=>120
,p_column_heading=>'Ta'
,p_column_html_expression=>'<span style="display:inline-block;width:86px;font-weight: bold;">#TA#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(161700148135391132)
,p_query_column_id=>13
,p_column_alias=>'NE'
,p_column_display_sequence=>130
,p_column_heading=>'Ne'
,p_column_html_expression=>'<span style="display:inline-block;width:86px;font-weight: bold;">#NE#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(161700506791391132)
,p_query_column_id=>14
,p_column_alias=>'TB'
,p_column_display_sequence=>140
,p_column_heading=>'Tb'
,p_column_html_expression=>'<span style="display:inline-block;width:100px;font-size: 12px;font-weight: bold;">#TB#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(161700948108391132)
,p_query_column_id=>15
,p_column_alias=>'SR'
,p_column_display_sequence=>150
,p_column_heading=>'Sr'
,p_column_html_expression=>'<span style="display:inline-block;width:80px;font-size: 12px;font-weight: bold;">#SR#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(161701385766391134)
,p_query_column_id=>16
,p_column_alias=>'ER'
,p_column_display_sequence=>160
,p_column_heading=>'Er'
,p_column_html_expression=>'<span style="display:inline-block;width:80px;font-size: 12px;font-weight: bold;">#ER#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(161440401873305047)
,p_query_column_id=>17
,p_column_alias=>'PB'
,p_column_display_sequence=>170
,p_column_heading=>'Pb'
,p_column_html_expression=>'<span style="display:inline-block;width: 130px;font-size: 12px;font-weight: bold;">#PB#</span>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(161825663220110345)
,p_button_sequence=>10
,p_button_name=>'DOWNLOAD_FORMAT_LOAD_2024'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--primary:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Download Format Load 2024'
,p_button_redirect_url=>'#APP_FILES#FORMAT_LOAD_BARCODE_LABEL_PRINT_2024.xlsx'
,p_icon_css_classes=>'fa-download'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(161030039765418621)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(161029568324418616)
,p_button_name=>'CLEAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Clear'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(161030371499418623)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(161029568324418616)
,p_button_name=>'LOAD'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Load Data'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(161032311792418630)
,p_name=>'P9_FILE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(161031991205418629)
,p_prompt=>'Upload a File'
,p_display_as=>'NATIVE_FILE'
,p_grid_label_column_span=>0
,p_field_template=>2040785906935475274
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_multiple_files', 'N',
  'display_as', 'DROPZONE_BLOCK',
  'dropzone_description', 'Supported formats XLSX',
  'file_types', '.xlsx',
  'max_file_size', '100',
  'purge_file_at', 'SESSION',
  'storage_type', 'APEX_APPLICATION_TEMP_FILES')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(161032789213418640)
,p_name=>'P9_ERROR_ROW_COUNT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(161031991205418629)
,p_display_as=>'NATIVE_HIDDEN'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(161034491224418646)
,p_name=>'P9_FILE_NAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(161034039690418645)
,p_item_default=>'Pasted Data'
,p_prompt=>'Loaded File'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(161035656166418651)
,p_name=>'P9_XLSX_WORKSHEET'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(161034039690418645)
,p_prompt=>'XLSX Worksheet'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select p.sheet_display_name,',
'       p.sheet_file_name',
'  from apex_application_temp_files f,',
'       table( apex_data_parser.get_xlsx_worksheets( p_content => f.blob_content ) ) p',
' where f.name = :P9_FILE'))
,p_cHeight=>1
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sheet_count number;',
'begin',
'    select count(*)',
'      into l_sheet_count',
'      from apex_application_temp_files f,',
'           table( apex_data_parser.get_xlsx_worksheets( p_content => f.blob_content ) ) p',
'     where f.name = :P9_FILE;',
'    ',
'     -- display if the XSLX file contains multiple worksheets',
'    return ( l_sheet_count > 1 );',
'exception',
'    when others then ',
'        return false;',
'end;'))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'FUNCTION_BODY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'execute_validations', 'N',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(161034940833418648)
,p_computation_sequence=>10
,p_computation_item=>'P9_FILE_NAME'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select filename',
'  from apex_application_temp_files ',
' where name = :P9_FILE'))
,p_compute_when=>'P9_FILE'
,p_compute_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(161035396268418649)
,p_validation_name=>'Is valid file type'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if apex_data_parser.assert_file_type(',
'       p_file_name => :P9_FILE_NAME,',
'       p_file_type => apex_data_parser.c_file_type_xlsx )',
'then',
'    return true;',
'else',
'    :P9_FILE := null;',
'    return false;',
'end if;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'Invalid file type. Supported file types XLSX.'
,p_associated_item=>wwv_flow_imp.id(161032311792418630)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(160990899537843067)
,p_validation_name=>'No Duplicate In Database'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH parsed AS (',
'  SELECT',
'    p.*,',
'    ROW_NUMBER() OVER (ORDER BY NULL) AS rn',
'  FROM apex_application_temp_files f',
'  CROSS JOIN TABLE(',
'    apex_data_parser.parse(',
'      p_content         => f.blob_content,',
'      p_file_name       => f.filename,',
'      p_skip_rows       => 1,',
'      p_xlsx_sheet_name => :P9_XLSX_WORKSHEET,',
'      p_file_profile    => apex_data_loading.get_file_profile(',
'                             p_static_id => ''load_staging_barcode_2024''',
'                           )',
'    )',
'  ) p',
'  WHERE f.name = :P9_FILE',
'),',
'',
'data_rows AS (',
'  SELECT',
'    UPPER(col001) AS mat_form,',
'    UPPER(col002) AS company_code,',
'    UPPER(col003) AS bucket,',
'    UPPER(col004) AS origin,',
'    UPPER(col005) AS specific_origin,',
'    UPPER(col006) AS quality,',
'    UPPER(col007) AS supplier,',
'',
'    CASE',
'      WHEN REGEXP_LIKE(col008, ''^\d+$'')',
'      THEN TO_NUMBER(col008)',
'      ELSE NULL',
'    END AS crop_year,',
'',
'    UPPER(col009) AS additional_information,',
'',
'    CASE',
'      WHEN REGEXP_LIKE(col010, ''^\d+$'')',
'      THEN TO_NUMBER(col010)',
'      ELSE NULL',
'    END AS batch_no,',
'',
'    CASE',
'      WHEN REGEXP_LIKE(col011, ''^\d+(\.\d+)?$'')',
'      THEN TO_NUMBER(col011)',
'      ELSE NULL',
'    END AS gross,',
'',
'    CASE',
'      WHEN REGEXP_LIKE(col012, ''^\d+(\.\d+)?$'')',
'      THEN TO_NUMBER(col012)',
'      ELSE NULL',
'    END AS tare,',
'',
'    CASE',
'      WHEN REGEXP_LIKE(col013, ''^\d+(\.\d+)?$'')',
'      THEN TO_NUMBER(col013)',
'      ELSE NULL',
'    END AS net,',
'',
'    CASE',
'      WHEN REGEXP_LIKE(col014, ''^\d+$'')',
'      THEN TO_NUMBER(col014)',
'      ELSE NULL',
'    END AS total_barcode,',
'',
'    col015 as prefix_barcode',
'',
'  FROM parsed',
'  WHERE rn > 1',
'),',
'',
'numbered AS (',
'  SELECT',
'    d.*,',
'    NVL(',
'      SUM(total_barcode) OVER (',
'        PARTITION BY',
'          company_code,',
'          crop_year,',
'          supplier,',
'          specific_origin',
'        ORDER BY batch_no',
'        ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING',
'      ),',
'      0',
'    ) + 1 AS start_running_number',
'  FROM data_rows d',
'),',
'uploaded_excel AS (',
'    SELECT',
'      mat_form,',
'      company_code,',
'      bucket,',
'      origin,',
'      specific_origin,',
'      quality,',
'      supplier,',
'      crop_year,',
'      additional_information,',
'      batch_no,',
'      gross,',
'      tare,',
'      net,',
'      total_barcode,',
'      start_running_number,',
'      start_running_number + total_barcode - 1 AS end_running_number,',
'      prefix_barcode',
'    FROM numbered',
'    ORDER BY',
'      company_code,',
'      crop_year,',
'      supplier,',
'      specific_origin,',
'      batch_no',
')',
'SELECT u.*',
'FROM uploaded_excel u',
'WHERE EXISTS (',
'  SELECT 1',
'  FROM xtd_kdk_lp_staging_barcode s',
'  WHERE s.company_code    = u.company_code',
'    AND s.specific_origin = u.specific_origin',
'    AND s.supplier        = u.supplier',
'    AND s.crop_year       = u.crop_year',
'    AND s.batch_no        = u.batch_no',
');'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Data yang akan diupload ada yang sudah didatabase'
,p_when_button_pressed=>wwv_flow_imp.id(161030371499418623)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(160991115744843069)
,p_validation_name=>'No Prefix Empty'
,p_validation_sequence=>30
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  v_count NUMBER;',
'BEGIN',
'  SELECT COUNT(*)',
'  INTO v_count',
'  FROM (',
'    SELECT *',
'    FROM (',
'      SELECT',
'        p.*,',
'        ROW_NUMBER() OVER (ORDER BY NULL) AS rn',
'      FROM apex_application_temp_files f',
'      CROSS JOIN TABLE(',
'        apex_data_parser.parse(',
'          p_content         => f.blob_content,',
'          p_file_name       => f.filename,',
'          p_skip_rows       => 1,',
'          p_xlsx_sheet_name => :P9_XLSX_WORKSHEET,',
'          p_file_profile    => apex_data_loading.get_file_profile(',
'                                 p_static_id => ''load_staging_barcode_2024''',
'                               )',
'        )',
'      ) p',
'      WHERE f.name = :P9_FILE',
'    )',
'    WHERE rn > 1',
'      AND TRIM(col015) IS NOT NULL',
'  );',
'',
'  RETURN v_count > 0;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'Data pada kolom prefix_barcode tidak boleh kosong'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(161030371499418623)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(161441655356305059)
,p_validation_name=>'No Duplicate Batch No'
,p_validation_sequence=>40
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH parsed AS (',
'  SELECT',
'    p.*,',
'    ROW_NUMBER() OVER (ORDER BY NULL) AS rn',
'  FROM apex_application_temp_files f',
'  CROSS JOIN TABLE(',
'    apex_data_parser.parse(',
'      p_content         => f.blob_content,',
'      p_file_name       => f.filename,',
'      p_skip_rows       => 1,',
'      p_xlsx_sheet_name => :P9_XLSX_WORKSHEET,',
'      p_file_profile    => apex_data_loading.get_file_profile(',
'                             p_static_id => ''load_staging_barcode_2024''',
'                           )',
'    )',
'  ) p',
'  WHERE f.name = :P9_FILE',
'),',
'data_rows AS (',
'  SELECT',
'    UPPER(col001) AS mat_form,',
'    UPPER(col002) AS company_code,',
'    UPPER(col003) AS bucket,',
'    UPPER(col004) AS origin,',
'    UPPER(col005) AS specific_origin,',
'    UPPER(col006) AS quality,',
'    UPPER(col007) AS supplier,',
'',
'    CASE',
'      WHEN REGEXP_LIKE(col008, ''^\d+$'')',
'      THEN TO_NUMBER(col008)',
'      ELSE NULL',
'    END AS crop_year,',
'',
'    UPPER(col009) AS additional_information,',
'',
'    CASE',
'      WHEN REGEXP_LIKE(col010, ''^\d+$'')',
'      THEN TO_NUMBER(col010)',
'      ELSE NULL',
'    END AS batch_no,',
'',
'    CASE',
'      WHEN REGEXP_LIKE(col011, ''^\d+(\.\d+)?$'')',
'      THEN TO_NUMBER(col011)',
'      ELSE NULL',
'    END AS gross,',
'',
'    CASE',
'      WHEN REGEXP_LIKE(col012, ''^\d+(\.\d+)?$'')',
'      THEN TO_NUMBER(col012)',
'      ELSE NULL',
'    END AS tare,',
'',
'    CASE',
'      WHEN REGEXP_LIKE(col013, ''^\d+(\.\d+)?$'')',
'      THEN TO_NUMBER(col013)',
'      ELSE NULL',
'    END AS net,',
'',
'    CASE',
'      WHEN REGEXP_LIKE(col014, ''^\d+$'')',
'      THEN TO_NUMBER(col014)',
'      ELSE NULL',
'    END AS total_barcode',
'',
'  FROM parsed',
'  WHERE rn > 1',
')',
'SELECT',
'  company_code,',
'  crop_year,',
'  supplier,',
'  specific_origin,',
'  batch_no,',
'  COUNT(*) AS jumlah',
'FROM data_rows',
'GROUP BY',
'  company_code,',
'  crop_year,',
'  supplier,',
'  specific_origin,',
'  batch_no',
'HAVING COUNT(*) > 1;'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Kolom Batch No Harus Unik'
,p_when_button_pressed=>wwv_flow_imp.id(161030371499418623)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(162501758552000237)
,p_validation_name=>'Check Master Serial Barcode'
,p_validation_sequence=>50
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_count_content NUMBER;',
'    v_count_load_data NUMBER;',
'    v_result NUMBER;',
'BEGIN',
'    WITH parsed AS (',
'      SELECT',
'        p.*,',
'        ROW_NUMBER() OVER (ORDER BY NULL) AS rn',
'      FROM apex_application_temp_files f',
'      CROSS JOIN TABLE(',
'        apex_data_parser.parse(',
'          p_content         => f.blob_content,',
'          p_file_name       => f.filename,',
'          p_skip_rows       => 1,',
'          p_xlsx_sheet_name => :P9_XLSX_WORKSHEET,',
'          p_file_profile    => apex_data_loading.get_file_profile(',
'                                 p_static_id => ''load_staging_barcode_2024''',
'                               )',
'        )',
'      ) p',
'      WHERE f.name = :P9_FILE',
'    ),',
'',
'    data_rows AS (',
'        SELECT',
'            UPPER(col001) AS mat_form,',
'            UPPER(col002) AS company_code,',
'            UPPER(col003) AS bucket,',
'            UPPER(col004) AS origin,',
'            UPPER(col005) AS specific_origin,',
'            UPPER(col006) AS quality,',
'            UPPER(col007) AS supplier,',
'            UPPER(col009) AS additional_information',
'        FROM parsed',
'        WHERE rn > 1',
'    ),',
'',
'    unpivoted AS (',
'        SELECT ''mat form''       AS content,        mat_form        AS value FROM data_rows',
'        UNION ALL SELECT ''company code'',           company_code             FROM data_rows',
'        UNION ALL SELECT ''bucket'',                 bucket                   FROM data_rows',
'        UNION ALL SELECT ''origin'',                 origin                   FROM data_rows',
'        UNION ALL SELECT ''specific origin'',        specific_origin          FROM data_rows',
'        UNION ALL SELECT ''quality (ab test)'',      quality                  FROM data_rows',
'        UNION ALL SELECT ''opkoper'',               supplier                 FROM data_rows',
'        UNION ALL SELECT ''additional information'', additional_information   FROM data_rows',
'    )',
'',
'    SELECT COUNT(*)',
'    INTO v_count_content',
'    FROM unpivoted u',
'    JOIN xtd_kdk_master_serial_barcode m',
'      ON UPPER(m.content) = UPPER(u.content)',
'    WHERE TO_CHAR(UPPER(m.serial)) = TO_CHAR(UPPER(u.value));',
'',
'    WITH parsed AS (',
'      SELECT',
'        p.*,',
'        ROW_NUMBER() OVER (ORDER BY NULL) AS rn',
'      FROM apex_application_temp_files f',
'      CROSS JOIN TABLE(',
'        apex_data_parser.parse(',
'          p_content         => f.blob_content,',
'          p_file_name       => f.filename,',
'          p_skip_rows       => 1,',
'          p_xlsx_sheet_name => :P9_XLSX_WORKSHEET,',
'          p_file_profile    => apex_data_loading.get_file_profile(',
'                                 p_static_id => ''load_staging_barcode_2024''',
'                               )',
'        )',
'      ) p',
'      WHERE f.name = :P9_FILE',
'    ),',
'',
'    data_rows AS (',
'        SELECT',
'            UPPER(col001) AS mat_form,',
'            UPPER(col002) AS company_code,',
'            UPPER(col003) AS bucket,',
'            UPPER(col004) AS origin,',
'            UPPER(col005) AS specific_origin,',
'            UPPER(col006) AS quality,',
'            UPPER(col007) AS supplier,',
'            UPPER(col009) AS additional_information',
'        FROM parsed',
'        WHERE rn > 1',
'    )',
'    SELECT COUNT(*)',
'    INTO v_count_load_data',
'    FROM data_rows;',
'',
'    v_result := v_count_content/v_count_load_data;',
'',
'    -- RAISE_APPLICATION_ERROR(-20001, ''count content : '' || v_count_content || '', count data load : '' || v_count_load_data || '', result : '' || v_count_content/v_count_load_data);',
'    RETURN v_result = 8;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'Ada data yang tidak ada di master serial barcode, harap cek master serial barcode'
,p_when_button_pressed=>wwv_flow_imp.id(161030371499418623)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(162501947231000239)
,p_validation_name=>'Crop Year Is 2024'
,p_validation_sequence=>60
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH parsed AS (',
'  SELECT',
'    p.*,',
'    ROW_NUMBER() OVER (ORDER BY NULL) AS rn',
'  FROM apex_application_temp_files f',
'  CROSS JOIN TABLE(',
'    apex_data_parser.parse(',
'      p_content         => f.blob_content,',
'      p_file_name       => f.filename,',
'      p_skip_rows       => 1,',
'      p_xlsx_sheet_name => :P9_XLSX_WORKSHEET,',
'      p_file_profile    => apex_data_loading.get_file_profile(',
'                             p_static_id => ''load_staging_barcode_2024''',
'                           )',
'    )',
'  ) p',
'  WHERE f.name = :P9_FILE',
'),',
'data_rows AS (',
'  SELECT',
'    UPPER(col001) AS mat_form,',
'    UPPER(col002) AS company_code,',
'    UPPER(col003) AS bucket,',
'    UPPER(col004) AS origin,',
'    UPPER(col005) AS specific_origin,',
'    UPPER(col006) AS quality,',
'    UPPER(col007) AS supplier,',
'    UPPER(col008) AS crop_year,',
'    UPPER(col009) AS additional_information,',
'    col010        AS batch_no,',
'    col011        AS gross,',
'    col012        AS tare,',
'    col013        AS net,',
'    col014        AS total_barcode',
'',
'  FROM parsed',
'  WHERE rn > 1',
')',
'SELECT crop_year',
'FROM data_rows',
'WHERE TO_CHAR(crop_year) = ''24'';'))
,p_validation_type=>'EXISTS'
,p_error_message=>'Crop year harus 2024'
,p_when_button_pressed=>wwv_flow_imp.id(161030371499418623)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(161033105933418640)
,p_name=>'Upload a File'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9_FILE'
,p_condition_element=>'P9_FILE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(161033648120418643)
,p_event_id=>wwv_flow_imp.id(161033105933418640)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(161036031349418652)
,p_name=>'Submit worksheet on change'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9_XLSX_WORKSHEET'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(161036549732418654)
,p_event_id=>wwv_flow_imp.id(161036031349418652)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(160990821774843066)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'INSERT Batch'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'INSERT INTO xtd_kdk_lp_staging_barcode (',
'  mat_form,',
'  company_code,',
'  bucket,',
'  origin,',
'  specific_origin,',
'  quality,',
'  supplier,',
'  crop_year,',
'  additional_information,',
'  batch_no,',
'  gross,',
'  tare,',
'  net,',
'  total_barcode,',
'  start_running_number,',
'  end_running_number,',
'  prefix_barcode,',
'  created_by,',
'  created_date',
')',
'WITH parsed AS (',
'  SELECT',
'    p.*,',
'    ROW_NUMBER() OVER (ORDER BY NULL) AS rn',
'  FROM apex_application_temp_files f',
'  CROSS JOIN TABLE(',
'    apex_data_parser.parse(',
'      p_content         => f.blob_content,',
'      p_file_name       => f.filename,',
'      p_skip_rows       => 1,',
'      p_xlsx_sheet_name => :P9_XLSX_WORKSHEET,',
'      p_file_profile    => apex_data_loading.get_file_profile(',
'                             p_static_id => ''load_staging_barcode_2024''',
'                           )',
'    )',
'  ) p',
'  WHERE f.name = :P9_FILE',
'),',
'',
'data_rows AS (',
'  SELECT',
'    UPPER(col001) AS mat_form,',
'    UPPER(col002) AS company_code,',
'    UPPER(col003) AS bucket,',
'    UPPER(col004) AS origin,',
'    UPPER(col005) AS specific_origin,',
'    UPPER(col006) AS quality,',
'    UPPER(col007) AS supplier,',
'',
'    CASE',
'      WHEN REGEXP_LIKE(col008, ''^\d+$'')',
'      THEN TO_NUMBER(col008)',
'      ELSE NULL',
'    END AS crop_year,',
'',
'    UPPER(col009) AS additional_information,',
'',
'    CASE',
'      WHEN REGEXP_LIKE(col010, ''^\d+$'')',
'      THEN TO_NUMBER(col010)',
'      ELSE NULL',
'    END AS batch_no,',
'',
'    CASE',
'      WHEN REGEXP_LIKE(col011, ''^\d+(\.\d+)?$'')',
'      THEN TO_NUMBER(col011)',
'      ELSE NULL',
'    END AS gross,',
'',
'    CASE',
'      WHEN REGEXP_LIKE(col012, ''^\d+(\.\d+)?$'')',
'      THEN TO_NUMBER(col012)',
'      ELSE NULL',
'    END AS tare,',
'',
'    CASE',
'      WHEN REGEXP_LIKE(col013, ''^\d+(\.\d+)?$'')',
'      THEN TO_NUMBER(col013)',
'      ELSE NULL',
'    END AS net,',
'',
'    CASE',
'      WHEN REGEXP_LIKE(col014, ''^\d+$'')',
'      THEN TO_NUMBER(col014)',
'      ELSE NULL',
'    END AS total_barcode,',
'',
'    UPPER(col015) AS PREFIX_BARCODE',
'',
'  FROM parsed',
'  WHERE rn > 1',
'),',
'existing_totals AS (',
'  SELECT',
'    company_code,',
'    crop_year,',
'    supplier,',
'    specific_origin,',
'    prefix_barcode,',
'    SUM(TOTAL_BARCODE) AS TOTAL_EXISTING',
'  FROM xtd_kdk_lp_staging_barcode',
'  GROUP BY',
'    company_code,',
'    crop_year,',
'    supplier,',
'    specific_origin,',
'    prefix_barcode',
'),',
'numbered AS (',
'  SELECT',
'    d.*,',
'    NVL(e.total_existing, 0)',
'    +',
'    NVL(',
'      SUM(d.total_barcode) OVER (',
'        PARTITION BY',
'          d.company_code,',
'          d.crop_year,',
'          d.supplier,',
'          d.specific_origin',
'        ORDER BY d.batch_no',
'        ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING',
'      ),',
'      0',
'    )',
'    + 1 AS start_running_number',
'  FROM data_rows d',
'  LEFT JOIN existing_totals e',
'    ON e.company_code    = d.company_code',
'   AND e.crop_year       = d.crop_year',
'   AND e.supplier        = d.supplier',
'   AND e.specific_origin = d.specific_origin',
'   AND e.prefix_barcode  = d.prefix_barcode',
')',
'SELECT',
'  mat_form,',
'  company_code,',
'  bucket,',
'  origin,',
'  specific_origin,',
'  quality,',
'  supplier,',
'  crop_year,',
'  additional_information,',
'  batch_no,',
'  gross,',
'  tare,',
'  net,',
'  total_barcode,',
'  start_running_number,',
'  start_running_number + total_barcode - 1 AS end_running_number,',
'  prefix_barcode,',
'  :APP_USER,',
'  CURRENT_TIMESTAMP',
'FROM numbered;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(161030371499418623)
,p_internal_uid=>11589425258405046
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(161031233622418626)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Clear Cache'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>':REQUEST = ''CLEAR'' or :P9_ERROR_ROW_COUNT = 0 or :REQUEST = ''LOAD'''
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>11629837105980606
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(160991041359843068)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(161030371499418623)
,p_internal_uid=>11589644843405048
);
wwv_flow_imp.component_end;
end;
/
