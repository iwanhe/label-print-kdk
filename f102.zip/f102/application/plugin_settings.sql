prompt --application/plugin_settings
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3414731422963618
,p_default_application_id=>102
,p_default_id_offset=>149401396516438020
,p_default_owner=>'KDK'
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(160820742938215204)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'include_slider', 'Y')).to_clob
,p_version_scn=>10785493
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(160821065236215207)
,p_plugin_type=>'DYNAMIC ACTION'
,p_plugin=>'NATIVE_OPEN_AI_ASSISTANT'
,p_version_scn=>10785493
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(160821345937215207)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_DATE_PICKER_APEX'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'appearance_behavior', 'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON',
  'days_outside_month', 'VISIBLE',
  'show_on', 'FOCUS',
  'time_increment', '15')).to_clob
,p_version_scn=>10785493
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(160821650708215207)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_GEOCODED_ADDRESS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'background', 'default',
  'display_as', 'LIST',
  'map_preview', 'POPUP:ITEM',
  'match_mode', 'RELAX_HOUSE_NUMBER',
  'show_coordinates', 'N')).to_clob
,p_version_scn=>10785493
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(160821979135215207)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_MAP_REGION'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_vector_tile_layers', 'Y')).to_clob
,p_version_scn=>10785493
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(160822265904215207)
,p_plugin_type=>'WEB SOURCE TYPE'
,p_plugin=>'NATIVE_BOSS'
,p_version_scn=>10785493
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(160822531037215207)
,p_plugin_type=>'WEB SOURCE TYPE'
,p_plugin=>'NATIVE_ADFBC'
,p_version_scn=>10785493
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(160822848944215207)
,p_plugin_type=>'PROCESS TYPE'
,p_plugin=>'NATIVE_GEOCODING'
,p_attribute_01=>'RELAX_HOUSE_NUMBER'
,p_version_scn=>10785493
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(160823134829215209)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_SINGLE_CHECKBOX'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', 'Y',
  'unchecked_value', 'N')).to_clob
,p_version_scn=>10785493
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(160823468278215209)
,p_plugin_type=>'REGION TYPE'
,p_plugin=>'NATIVE_IR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'actions_menu_structure', 'IG')).to_clob
,p_version_scn=>10785493
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(160823718519215209)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_SELECT_MANY'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_values_as', 'separated')).to_clob
,p_version_scn=>10785493
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(160824082766215209)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_COLOR_PICKER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'mode', 'FULL')).to_clob
,p_version_scn=>10785493
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(160824388793215209)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_STAR_RATING'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'default_icon', 'fa-star',
  'tooltip', '#VALUE#')).to_clob
,p_version_scn=>10785493
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(160824627794215209)
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_YES_NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_style', 'SWITCH_CB',
  'off_value', 'N',
  'on_value', 'Y')).to_clob
,p_version_scn=>10785493
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(170176307602232134)
,p_plugin_type=>'DYNAMIC ACTION'
,p_plugin=>'PLUGIN_BE.APEXRND.AOP_DA'
,p_attribute_01=>'https://api.apexofficeprint.com/'
,p_attribute_02=>'46AAEE72D535AAC3E0637203000A38AB'
,p_attribute_10=>'development'
,p_version_scn=>26459098
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(170177395948242907)
,p_plugin_type=>'PROCESS TYPE'
,p_plugin=>'PLUGIN_BE.APEXRND.AOP'
,p_attribute_01=>'https://api.apexofficeprint.com/'
,p_attribute_02=>'46AAEE72D535AAC3E0637203000A38AB'
,p_version_scn=>26388442
);
wwv_flow_imp_shared.create_plugin_setting(
 p_id=>wwv_flow_imp.id(170177910729248187)
,p_plugin_type=>'DYNAMIC ACTION'
,p_plugin=>'PLUGIN_BE.APEXRND.AOP_CONVERT_DA'
,p_attribute_01=>'https://api.apexofficeprint.com/'
,p_attribute_02=>'46AAEE72D535AAC3E0637203000A38AB'
,p_version_scn=>26388381
);
wwv_flow_imp.component_end;
end;
/
