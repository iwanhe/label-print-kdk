prompt --application/deployment/install/install_view
begin
--   Manifest
--     INSTALL: INSTALL-view
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3414731422963618
,p_default_application_id=>102
,p_default_id_offset=>149401396516438020
,p_default_owner=>'KDK'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(170675661379441602)
,p_install_id=>wwv_flow_imp.id(160840780812216643)
,p_name=>'view'
,p_sequence=>130
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  CREATE OR REPLACE FORCE EDITIONABLE VIEW "V_KDK_LP_BARCODE" ("BARCODE_ID", "ID", "MAT_FORM", "COMPANY_CODE", "BUCKET", "ORIGIN", "SPECIFIC_ORIGIN", "QUALITY", "SUPPLIER", "CROP_YEAR", "ADDITIONAL_INFORMATION", "BATCH_NO", "GROSS", "TARE", "NET", "T'
||'OTAL_BARCODE", "START_RUNNING_NUMBER", "END_RUNNING_NUMBER", "PREFIX_BARCODE", "CREATED_DATE", "CREATED_BY", "UPDATED_DATE", "UPDATED_BY", "XTD_KDK_LP_JOB_ID", "STATUS", "RUNNING_NUMBER", "BARCODE", "BARCODE_2024") AS ',
'  SELECT ',
'    bc."ID" AS BARCODE_ID,sbc."ID",sbc."MAT_FORM",sbc."COMPANY_CODE",sbc."BUCKET",sbc."ORIGIN",sbc."SPECIFIC_ORIGIN",sbc."QUALITY",sbc."SUPPLIER",sbc."CROP_YEAR",sbc."ADDITIONAL_INFORMATION",sbc."BATCH_NO",sbc."GROSS",sbc."TARE",sbc."NET",sbc."TOTAL_'
||'BARCODE",sbc."START_RUNNING_NUMBER",sbc."END_RUNNING_NUMBER",sbc."PREFIX_BARCODE",sbc."CREATED_DATE",sbc."CREATED_BY",sbc."UPDATED_DATE",sbc."UPDATED_BY",sbc."XTD_KDK_LP_JOB_ID",sbc."STATUS",',
'    bc.running_number,',
'    ARRANGE_BARCODE(bc.id) AS BARCODE,',
'    CASE ',
'        WHEN sbc.crop_year = ''24'' THEN ARRANGE_BARCODE(bc.id, TRUE)',
'        ELSE ''-''',
'    END AS BARCODE_2024',
'FROM xtd_kdk_lp_staging_barcode sbc',
'JOIN xtd_kdk_lp_barcode bc ON sbc.id = bc.xtd_kdk_lp_staging_barcode_id; '))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(170675703075441602)
,p_script_id=>wwv_flow_imp.id(170675661379441602)
,p_object_owner=>'#OWNER#'
,p_object_type=>'VIEW'
,p_object_name=>'V_KDK_LP_BARCODE'
);
wwv_flow_imp.component_end;
end;
/
