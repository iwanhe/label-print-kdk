prompt --application/deployment/install/install_function
begin
--   Manifest
--     INSTALL: INSTALL-function
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3414731422963618
,p_default_application_id=>102
,p_default_id_offset=>149401396516438020
,p_default_owner=>'KDK'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(170673867569419945)
,p_install_id=>wwv_flow_imp.id(160840780812216643)
,p_name=>'function'
,p_sequence=>110
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace FUNCTION arrange_barcode (',
'    p_id IN NUMBER,',
'    p_is_2024 IN BOOLEAN DEFAULT FALSE',
') RETURN VARCHAR2',
'IS',
'    -- record untuk staging barcode',
'    TYPE r_bc IS RECORD (',
'        company_code           VARCHAR2(10),',
'        mat_form               VARCHAR2(10),',
'        specific_origin        VARCHAR2(10),',
'        crop_year              VARCHAR2(10),',
'        quality                VARCHAR2(10),',
'        supplier               VARCHAR2(10),',
'        additional_information VARCHAR2(10),',
'        running_number         NUMBER,',
'        prefix_barcode         VARCHAR2(21)',
'    );',
'',
'    v_bc r_bc;',
'',
'    -- hasil mapping',
'    v_company_code           VARCHAR2(2);',
'    v_mat_form               VARCHAR2(2);',
'    v_specific_origin        VARCHAR2(2);',
'    v_quality                VARCHAR2(2);',
'    v_supplier               VARCHAR2(2);',
'    v_additional_information VARCHAR2(2);',
'',
'BEGIN',
'    /* ambil data utama */',
'    SELECT',
'        sbc.company_code,',
'        sbc.mat_form,',
'        sbc.specific_origin,',
'        sbc.crop_year,',
'        sbc.quality,',
'        sbc.supplier,',
'        sbc.additional_information,',
'        bc.running_number,',
'        sbc.prefix_barcode',
'    INTO v_bc',
'    FROM xtd_kdk_lp_staging_barcode sbc',
'    JOIN xtd_kdk_lp_barcode bc',
'        ON bc.xtd_kdk_lp_staging_barcode_id = sbc.id',
'    WHERE bc.id = p_id;',
'',
'    IF p_is_2024 = FALSE THEN',
'        /* mapping serial -> number */',
'        SELECT',
'            MAX(CASE WHEN content = ''COMPANY CODE''              AND serial = v_bc.company_code THEN LPAD(number_code, 2, ''0'') END) AS company_code,',
'            MAX(CASE WHEN content = ''SPECIFIC ORIGIN''           AND serial = v_bc.specific_origin THEN LPAD(number_code, 2, 0) END) AS specific_origin,',
'            MAX(CASE WHEN content = ''MAT FORM''                  AND serial = v_bc.mat_form THEN LPAD(number_code, 2, ''0'') END) AS mat_form,',
'            MAX(CASE WHEN content = ''QUALITY (AB TEST)''         AND serial = v_bc.quality THEN number_code END) AS quality,',
'            MAX(CASE WHEN content = ''ADDITIONAL INFORMATION''    AND serial = v_bc.additional_information THEN LPAD(number_code, 2, ''0'') END) AS additional_information,',
'            MAX(CASE WHEN content IN (''SUPPLIER'', ''OPKOPER'')                  AND serial = v_bc.supplier THEN LPAD(number_code, 2, ''0'') END) AS supplier',
'        INTO',
'            v_company_code,',
'            v_specific_origin,',
'            v_mat_form,',
'            v_quality,',
'            v_additional_information,',
'            v_supplier',
'        FROM xtd_kdk_master_serial_barcode;',
'',
'        RETURN',
'              v_company_code',
'            || v_mat_form',
'            || v_specific_origin',
'            || v_bc.crop_year',
'            || v_quality',
'            || v_supplier',
'            || v_additional_information',
'            || LPAD(v_bc.running_number, 5, ''0'');',
'    ELSE',
'        RETURN v_bc.prefix_barcode || LPAD(v_bc.running_number, 8, ''0'');',
'    ',
'    END IF;',
'',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        RETURN NULL;',
'END arrange_barcode;',
'/',
'create or replace FUNCTION is_transient_error(p_code NUMBER) RETURN BOOLEAN',
'as',
'begin',
'    return p_code in (-54, -60, -2049);',
'end "IS_TRANSIENT_ERROR";',
'/ '))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(170673948307419945)
,p_script_id=>wwv_flow_imp.id(170673867569419945)
,p_object_owner=>'#OWNER#'
,p_object_type=>'FUNCTION'
,p_object_name=>'ARRANGE_BARCODE'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(170674152272419945)
,p_script_id=>wwv_flow_imp.id(170673867569419945)
,p_object_owner=>'#OWNER#'
,p_object_type=>'FUNCTION'
,p_object_name=>'IS_TRANSIENT_ERROR'
);
wwv_flow_imp.component_end;
end;
/
