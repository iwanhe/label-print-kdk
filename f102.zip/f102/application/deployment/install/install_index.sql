prompt --application/deployment/install/install_index
begin
--   Manifest
--     INSTALL: INSTALL-index
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3414731422963618
,p_default_application_id=>102
,p_default_id_offset=>149401396516438020
,p_default_owner=>'KDK'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(163095674282385140)
,p_install_id=>wwv_flow_imp.id(160840780812216643)
,p_name=>'index'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  CREATE UNIQUE INDEX "XTD_KDK_LP_JOB_ID_PK" ON "XTD_KDK_LP_JOB" ("ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "XTD_KDK_LP_STAGING_BARCODE_ID_PK" ON "XTD_KDK_LP_STAGING_BARCODE" ("ID") ',
'  ;',
'',
'  CREATE INDEX "IDX_STAGING_JOB_ID" ON "XTD_KDK_LP_STAGING_BARCODE" ("XTD_KDK_LP_JOB_ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "XTD_KDK_LP_BARCODE_ID_PK" ON "XTD_KDK_LP_BARCODE" ("ID") ',
'  ;',
'',
'  CREATE INDEX "IDX_BARCODE_STG_ID" ON "XTD_KDK_LP_BARCODE" ("XTD_KDK_LP_STAGING_BARCODE_ID") ',
'  ;',
'',
'  CREATE INDEX "IDX_STAGING_STATUS_ID" ON "XTD_KDK_LP_STAGING_BARCODE" ("STATUS", "ID") ',
'  ;',
'',
'  CREATE INDEX "IDX_JOB_RUN_JOB_ID" ON "XTD_KDK_LP_JOB_RUN" ("XTD_KDK_LP_JOB_ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "XTD_KDK_LP_JOB_RUN_ID_PK" ON "XTD_KDK_LP_JOB_RUN" ("ID") ',
'  ; '))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(163095705724385140)
,p_script_id=>wwv_flow_imp.id(163095674282385140)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'IDX_BARCODE_STG_ID'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(163095989822385140)
,p_script_id=>wwv_flow_imp.id(163095674282385140)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'IDX_JOB_RUN_JOB_ID'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(163096160649385140)
,p_script_id=>wwv_flow_imp.id(163095674282385140)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'IDX_STAGING_JOB_ID'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(163096345146385140)
,p_script_id=>wwv_flow_imp.id(163095674282385140)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'IDX_STAGING_STATUS_ID'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(163096571725385140)
,p_script_id=>wwv_flow_imp.id(163095674282385140)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'XTD_KDK_LP_BARCODE_ID_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(163096729051385140)
,p_script_id=>wwv_flow_imp.id(163095674282385140)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'XTD_KDK_LP_JOB_ID_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(163096949146385140)
,p_script_id=>wwv_flow_imp.id(163095674282385140)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'XTD_KDK_LP_JOB_RUN_ID_PK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(163097182563385140)
,p_script_id=>wwv_flow_imp.id(163095674282385140)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'XTD_KDK_LP_STAGING_BARCODE_ID_PK'
);
wwv_flow_imp.component_end;
end;
/
