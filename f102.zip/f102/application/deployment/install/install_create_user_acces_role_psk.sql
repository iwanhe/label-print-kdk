prompt --application/deployment/install/install_create_user_acces_role_psk
begin
--   Manifest
--     INSTALL: INSTALL-create_user_acces_role_psk
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3414731422963618
,p_default_application_id=>102
,p_default_id_offset=>149401396516438020
,p_default_owner=>'KDK'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(168657316757795923)
,p_install_id=>wwv_flow_imp.id(160840780812216643)
,p_name=>'create_user_acces_role_psk'
,p_sequence=>90
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    CURSOR c_acl IS',
'        SELECT username, roles',
'        FROM (',
'            SELECT ''ADMIN'' username, ''Administrator'' roles FROM dual',
'            UNION ALL',
'            SELECT ''ADMIN_WH'', ''Admin_wh'' FROM dual',
'            UNION ALL',
'            SELECT ''DIREKTUR'', ''Direktur'' FROM dual',
'            UNION ALL',
'            SELECT ''WH'', ''WH'' FROM dual',
'            ',
'        );',
'BEGIN',
'    FOR u IN c_acl LOOP',
'        FOR r IN (',
'            SELECT REGEXP_SUBSTR(u.roles, ''[^,]+'', 1, LEVEL) role',
'            FROM dual',
'            CONNECT BY LEVEL <= REGEXP_COUNT(u.roles, '','') + 1',
'        ) LOOP',
'            APEX_ACL.ADD_USER_ROLE(',
'                p_application_id => :APP_ID,',
'                p_user_name      => u.username,',
'                p_role_static_id => TRIM(r.role)',
'            );',
'        END LOOP;',
'    END LOOP;',
'END;',
'/',
''))
);
wwv_flow_imp.component_end;
end;
/
